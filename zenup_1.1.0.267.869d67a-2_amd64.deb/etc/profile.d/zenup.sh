# Add zenup bin directory to path if user is in the right group

if [ "`/usr/bin/id -gn`" == "zenoss" ]; then
	export PATH=/opt/zenup/bin:$PATH;
fi
