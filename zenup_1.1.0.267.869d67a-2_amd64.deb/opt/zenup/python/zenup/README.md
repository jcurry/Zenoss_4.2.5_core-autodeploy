# ZenUp


## What is it?
ZenUp is Zenoss' tool for distributing and installing patches for numerous Zenoss products.  Currently, ZenUp is available for Core, Resource Manager, and CSA.  Future releases may include Impact and Analytics.

## Running ZenUp
Refer to the [wiki](https://github.com/zenoss/zenup/wiki)

## ZenUp API 
The `ZenUp` class is the base API for performing ZenUp operations. It takes a path variable, **$ZENUPVAR**, and loads all of the installed products from a *status.yaml* file.

### Methods
- *\_\_init\_\_ (path)* : Loads and validates the API from a status.yaml file located on the path.  If the file does not exist, then it is assumed that no products have been registered on the system.  Raises a `ZenUpException` if the file is invalid.

- *get_product (productKey)* : Searches for the ZenUp product by product id and name.  If no results are found, the object returned is `None`.

- *setup (source, home, name=None)* : Installs a new ZenUp product given the path to the source, and the path to the product's home directory.  Optionally, you can provide a default name, or alias, for which the product can be referred.

- *remove (productKey)* : Removes a ZenUp product by name or id.  It deletes the products' meta directory and updates the status file with the new product listing.  If for any reason, the product does not remove successfully, an Exception is raised, and the status yaml is updated without the named product.

- *info (zupfile)* : If the source given is valid, returns a [ZupArchive](./archive) object loaded with information about the manifest and the config yaml files.  Otherwise a `ZenUpException` is raised.

- *diff (productKey)* : Searches for a ZenUp product by product id and name. If found, performs a diff against the pristine source that is stored on the product with the path of the home that is stored on the product's [configuration](./config).

- *install (self, zupfile, test=False, force=False)* : Loads a zup file from a path, determines the associated product and attempts to install zup onto the product.  If *test* is set to `True`, then the changes generated from the zup will not be applied to the product. 

- *revert (self, productKey, hotfix=False, test=False, force=False)* : Reverts a zup for a specified product, if permitted by the zup, i.e., not constrained by the minimum downgrade version of the zup.

## ZupProduct

The `ZupProduct` class maintains information about a product's state.  The corresponding source tree contains product's source and any zups that have been installed on the system.

### Methods

- **load(cls, resource)** : [@classmethod] Loads all of the ZenUp products from a single zenup *status.yaml*.

- **setup(cls, source, path, home, name=None)** : [@classmethod] Registers a new zup product with zenup.

- *\_\_init\_\_(self, \**config)* : Instantiates a zup product given its product meta-data.  Required fields include the id ('id\_'),  the home directory ('home'), and the path to the zenup product info ('path').

- *remove(self)* : Unregisters a product by deleting the path directory

- *diff(self)* : Extracts the product's pristine (as well as its installed zup, where applicable) and compares the product's pristine source with the product's installed source.  Local diff calculation is limited by the filters that are specified by the product's source (or zup) configuration.

- *test(self, zup=None, no\_rps=False, no\_hotfix=False)* : Determines if a product installation is possible by checking the zup for compatibility and determining whether the patches will apply cleanly to the installation, considering any local changes.  No code changes will be applied to the installed product.  If the zup arg is None and either the no\_rps or no\_hotfix args are set, then zenup will test reverting the installed zup while trying to preserve local changes.

- *install(self, zup=None, force=False, no\_rps=False, no\_hotfix=False)* : Verifies and performs zup installations for a product

## Error Handling

`ZenUpException` is the standard exception handler for user errors, like when a user provides an invalid or incompatible file, cancels an operation, or when a zup fails to install because of code merge issue.

Other errors are categorized as under Exceptions and are described in further detail in the console and ZenUp logger. 

## Logging

There are two main loggers for ZenUp used for storing runtime information.

**ZenUp logger:**  Primary logger mainly used for capturing errors generated from the ZenUp API.

**Console logger:** Secondary logger for printing messages directly to the screen.  This logger should be used in lieu of using python print statements mainly because it is easier to manage and capture messages processed by this tool.
