##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################

import logging.config
from logging import FileHandler
from logging.handlers import RotatingFileHandler
from logging.handlers import TimedRotatingFileHandler
import os

##### AUDIT LOGLEVELS #####
BEGIN_LOG_LEVEL = 6
logging.addLevelName(BEGIN_LOG_LEVEL, "BEGIN")
def begin(self, message, *args, **kwargs):
    if self.isEnabledFor(BEGIN_LOG_LEVEL):
        self._log(BEGIN_LOG_LEVEL, message, args, **kwargs)
logging.Logger.begin = begin

END_LOG_LEVEL = 7
logging.addLevelName(END_LOG_LEVEL, "END")
def end(self, message, *args, **kwargs):
    if self.isEnabledFor(END_LOG_LEVEL):
        self._log(END_LOG_LEVEL, message, args, **kwargs)
logging.Logger.end = end

######################### Exceptions #########################

class ZenUpException(Exception):
    """
    Exceptions that occur on part of bad user input.  These exceptions will 
    print back to the user.
    """
    pass

class ZupArchiveException(ZenUpException):
    pass

class ZenUpProductException(ZenUpException):
    pass


######################### Loggers #########################

def _relativeToZENUPHOME(filename):
    """Returns the filename relative to $ZENUPHOME"""
    return filename if filename.startswith('/') else os.path.join(ZENUPHOME, "log", filename)

class ZenUpFileHandler(FileHandler):
    """Like python's FileHandler but relative to $ZENUPHOME"""
    def __init__(self, filename, mode='a', encoding=None, delay=0):
        filename = _relativeToZENUPHOME(filename)
        FileHandler.__init__(self, filename, mode, encoding, delay)

class ZenUpRotatingFileHandler(RotatingFileHandler):
    """Like python's RotatingFileHandler but relative to $ZENUPHOME"""
    def __init__(self, filename, mode='a', maxBytes=0, backupCount=0, encoding=None, delay=0):
        filename = _relativeToZENUPHOME(filename)
        RotatingFileHandler.__init__(self, filename, mode, maxBytes, backupCount, encoding, delay)

class ZenUpManualRotatingFileHandler(ZenUpRotatingFileHandler):
    class NeverLogFilter(logging.Filter):
        def filter(self, record):
            return False

    neverLogFilter = NeverLogFilter()

    def __init__(self, filename, mode='a', maxBytes=0, backupCount=0, encoding=None, delay=0):
        super(ZenUpManualRotatingFileHandler, self).__init__(filename, mode, maxBytes, backupCount, encoding, delay)
        self.addFilter(self.neverLogFilter)

    def enable(self):
        self.removeFilter(self.neverLogFilter)

    def disable(self):
        self.addFilter(self.neverLogFilter)

    def doRolloverNonEmpty(self):
        """
        Determine if rollover should occur.
        Don't rollover empty files
        """
        if self.stream:
            self.stream.seek(0, 2)  #due to non-posix-compliant Windows feature
            if self.stream.tell() > 0:
                self.doRollover()

    def isLogEmpty(self):
        if self.stream:
            self.stream.seek(0, 2)  #due to non-posix-compliant Windows feature
            if self.stream.tell() > 0:
                return False
        return True


    """
    def __init__(self, prefix, suffix, mode, maxBytes, backupCount, encoding, delay):
        import datetime
        now = datetime.datetime.now().strftime("%Y-%b-%d_%H-%M-%S")
        filename = "%s-%s%s" % (prefix, now, suffix)
        super(ZenUpManualRotatingFileHandler,self).__init__(filename, mode, maxBytes, backupCount, encoding, delay)
    """

class ZenUpTimedRotatingFileHandler(TimedRotatingFileHandler):
    """Like python's TimedFileHandler but relative to $ZENUPHOME"""
    def __init__(self, filename, when='h', interval=1, backupCount=0, encoding=None, delay=False, utc=False):
        filename = _relativeToZENUPHOME(filename)
        TimedRotatingFileHandler.__init__(self, filename, when, interval, backupCount, encoding, delay, utc)


######################### Initialization #########################

ZENUPHOME = os.environ.get("ZENUPHOME")
if not ZENUPHOME:
    raise ZenUpException("Environment variable $ZENUPHOME not set")

ZENUPVAR = os.path.join(ZENUPHOME, "var")
ZENUPETC = os.path.join(ZENUPHOME, "etc")
ZENUPLOG = os.path.join(ZENUPHOME, "log")

LOG_CONFIG = os.path.join(ZENUPETC, "log.conf")
if not os.path.isfile(LOG_CONFIG):
    raise ZenUpException("Log config file not found: %s" % LOG_CONFIG)
logging.config.fileConfig(LOG_CONFIG)
