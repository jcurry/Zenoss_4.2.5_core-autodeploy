Zenup Archive
===

ZenUp receives data relating to a product or GA update in an Archive file.  Typically, these archives are tgz files containing configuration(s), scripts and other relevant data.  In order to conveniently process this data, an *Archive* base class is used to account for the different types of Archival data compatible with the ZenUp tool.

## Version
1.0

## How it Works
Consider the pristine source and the zup.  Both archives are similarly packaged in a tgz file and both have their own config.yaml.  However, the two archives are too different to be packaged as the same class, considering their vastly different scripts and overall file structure.  This is where the `zenup.archive.Archive` class fits in.

### Initialization
The *Archive* type has three static variables; each utilized in distinguishing one archive from another and useful in checking the validity of the Archive itself.

- **\_file\_structure:** A list of the minimum files in the archive to be considered valid.
- **\_config:** A list of tuples with information on how to load and store any configuration data within the archive.
- **\_scripts:** A list of scripts that can be executed and exist within the archive

### Class Methods

**Archive.load (resource):** Checks the validity of an archive and loads the configuration data.  This call is useful when you are interested in analyzing the contents of an archive, without actually having to extract all the contents of the resource.

**Archive.extract (resource):** Context manager that checks the validity of an archive, loads the configuration, and extracts the data into a temporary location. When the context manager exits, the extracted data deletes itself from the filesystem.

### Instance Methods

*\_\_init\_\_ (resource)* : Initializes an Archive instance for a given resource path.

*is_open ()* : Returns a boolean that indicated whether an archive has been extracted.

*extract (path=None)* : Extracts the contents of an Archive into a specified path.  If a path is not, specified, then the contents are written to SYSTEMP.

*compress (path, filename=None)* : Compresses the contents of an extracted archive into a specified path with a given filename.  If a filename is not specified, then the filename is the file base name of `self.resource`.

*remove ()* : Deletes the extracted archive data from the filesystem, while still retaining the original resource.

*run_script (script)* : Runs the script if it exists in the Archive and is defined by the Archive class.  If the script is not defined by the Archive class, then an ArchiveError is raised.  However, if the script doesn't exist but is defined, then it returns with no error raised.  The Archive must be extracted before any scripts can be run.

## Inheritance

### PristineSource
Archive with data relating to a product's pristine install.  This should return no local diffs against a new product installation

#### Initialization

- **Minimum Requirements**
	- src/
	- config.yaml
- **Configuration**
	- config.yaml
- **Scripts**
	- install

### ZupArchive
Archive with data relating to a product's zup.  

#### Initialization

- **Minimum Requirements**
	- config.yaml
	- manifest.yaml
- **Configuration**
	- config.yaml
	- manifest.yaml
- **Scripts**
	- check
	- post
	- pre

#### Instance Methods

*apply_patches (path)* : Applies patches from a zup onto a specific path as described in the archive's manifest.
