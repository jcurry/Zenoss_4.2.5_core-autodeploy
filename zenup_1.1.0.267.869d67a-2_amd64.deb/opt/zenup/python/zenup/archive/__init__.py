##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################

import os
import logging
import shutil
import subprocess
import tarfile
import tempfile
from contextlib import contextmanager

from zenup.config import Configuration
from zenup import ZenUpException

console = logging.getLogger("console")

class ArchiveError(Exception):
    pass


class Archive(object):
    """
    Object that extracts, manipulates, and stores information pertaining to a
    ZenUp archive.

    @static _file_structure: list of required files and directories
    @static _config: list of config files to be loaded as tuples of
        (attribute name, relative path, class loader)
    @static _scripts: path to scripts associated with the archive
    """
    
    _file_structure = ['config.yaml']
    _config = [("config", "config.yaml", Configuration),]

    def __init__(self, resource):
        self.resource = resource
        self.path = None
        self.config = None
        self.extract = self._extract

    @classmethod
    @contextmanager
    def extract(cls, resource):
        """
        Context manager that loads and extracts a ZenUp Archive.

        @param resource: path to the resource
        @returns Archive
        """

        obj = None
        try:
            obj = cls(resource)
            obj.extract()
            yield obj
        finally:
            if obj:
                try:
                    obj.remove()
                except Exception: pass

    @classmethod
    def load(cls, resource):
        """
        Loads configuration data pertaining to a ZenUp Archive.

        @param resource: path to the resource
        @returns Archive
        """
        obj = cls(resource)
        with obj.safeopen(): pass
        return obj

    @contextmanager
    def safeopen(self):
        """
        Context manager for opening TarFile objects.  Use Archive.load, 
        Archive.open, or self.extract instead.

        @yields tarfile.TarFile
        @raises ArchiveError
        """
        # Check the path of the resource
        if not self.resource or \
           not os.path.exists(self.resource) or \
           not os.access(self.resource, os.R_OK) or \
           not tarfile.is_tarfile(self.resource):
            raise ArchiveError("Path doesn't exist, no access, or not correct "
                               "file type")
        
        tar = None
        try:
            tar = tarfile.open(self.resource)
            # Validate the file structure
            if not set(self._file_structure).issubset(tar.getnames()):
                raise ArchiveError("Resource is invalid, corrupt, or missing "
                                   "files")

            # Load the configuration(s)
            self.configure(tar)
            yield tar
        except tarfile.TarError:
            raise ArchiveError("Resource is invalid, corrupt, or missing "
                               "files")
        finally:
            if tar:
                try:
                    tar.close()
                except Exception: pass
            
    def is_open(self):
        return self.path is not None

    def configure(self, tar):
        """
        Loads configuration files from a ZenUp Archive resource.  Use
        Archive.load, Archive.open, or self.extract instead.

        @param tar: TarFile object being read
        """

        for attr, name, cls in self._config:
            fp = tar.extractfile(name)
            setattr(self, attr, cls.load(fp))
 
    def _extract(self, path=None):
        """
        Extracts a ZenUp Archive into temporary directory and loads its
        configuration.

        @param path: (optional) base directory to store the extracted archive.
        @raises ArchiveError
        """

        if self.is_open():
            raise ArchiveError("Resource already open!")
        basename = os.path.basename(self.resource) + "_"

        if path is not None:
            if not os.path.exists(path) or \
               not os.path.isdir(path) or \
               not os.access(path, os.R_OK) or \
               not os.access(path, os.W_OK) or \
               not os.access(path, os.X_OK):
                raise ArchiveError("Unable to write to path")

        with self.safeopen() as tar:
            self.path = tempfile.mkdtemp(prefix=basename, dir=path)
            tar.extractall(path=self.path)

    def compress(self, path, filename=None):
        """
        Tars up the extracted archive and stores the data in a specified path.

        @param path: directory to store the compressed Archive
        @param filename: (optional) name of the file to store the Archive
        @raises ArchiveError
        """
        
        if not self.is_open():
            raise ArchiveError("Resource not open!")
        elif not os.path.exists(path) or \
             not os.path.isdir(path) or \
             not os.access(path, os.R_OK) or \
             not os.access(path, os.W_OK) or \
             not os.access(path, os.X_OK):
            raise ArchiveError("Unable to write to path")

        if not filename:
            filename = os.path.basename(self.resource)

        resource = os.path.join(path, filename)
        if os.path.exists(resource):
            raise ArchiveError("Cannot write to file, already exists!")

        tar = None
        try:
            # TODO: Save the configuration(s) on the object back to the YAML
            # file
            
            tar = tarfile.open(resource, "w:gz")
            for filename in os.listdir(self.path):
                tar.add(os.path.join(self.path, filename), arcname=filename)
        except (tarfile.TarError):
            raise ArchiveError("Unable to export tarfile")
        finally:
            if tar:
                try:
                    tar.close()
                except Exception: pass

    def remove(self):
        """
        Remove the extracted archive data from the filesystem.

        @raises ArchiveError
        """
        
        if not self.is_open():
            raise ArchiveError("Resource not open!")
        shutil.rmtree(self.path)
        self.path = None

    def run_script(self, script):
        """
        Run a script stored on the Archive.  Looks up the script name
        in the self._scripts list to verify whether the script can be run.
        If the script doesn't exist, but is defined on the object, then
        return successfully.

        @param script: Name of the script to run
        @raises ArchiveError
        """
        
        if not self.is_open():
            raise ArchiveError("Resource not open!")
        
        if type(script) is str:
            script = script.split()
        elif type(script) is not list:
            raise ArchiveError("Script %s not found!" % script)

        path = os.path.join(self.path, script[0])
        if not os.path.exists(path):
            console.warning("Unable to find specified lifecycle script {0}, skipping".format(path))
            return
            # raise ArchiveError("Script %s not found!" % script)
        elif not os.path.isfile(path) or \
             not os.access(path, os.X_OK) or \
             not os.access(path, os.R_OK):
            raise ArchiveError("Could not run script %s" % script)

        script[0] = path
        p = subprocess.Popen(' '.join(script), stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, shell=True)

        line = True
        while line:
            line = p.stdout.readline()
            console.info(line.rstrip('\n'))

        p.wait()
        if p.returncode:
            error_text = ""
            if p.returncode == 126:
                error_text = "Script failed due to a permissions issue - check that {0} " \
                             "is not mounted with 'noexec'.  If it is, either re-mount it " \
                             "without 'noexec' or specify a different temporary directory " \
                             "location (like /dev/shm, for example) by setting the 'TMPDIR' " \
                             "environment variable.".format(tempfile.gettempdir())
            exception_text = 'Script "%s" returned a non-zero exit code %s.  ' % (script, p.returncode)
            raise ArchiveError(exception_text + error_text)
