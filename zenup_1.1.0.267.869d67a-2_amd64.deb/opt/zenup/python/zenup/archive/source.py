##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################

import os

from zenup.archive import Archive
from zenup.config.source import SourceConfiguration

class PristineSource(Archive):
    """
    Class that loads data related to a pristine source Archive.
    """
    
    _file_structure = ["src", 
                       "config.yaml",]
    _config = [("config", "config.yaml", SourceConfiguration),]

    def __init__(self, resource):
        super(PristineSource, self).__init__(resource)

    def source_path(self):
        return os.path.join(self.path, "src")

    @classmethod
    def extract(cls, resource):
        return super(PristineSource, cls).extract(resource)

    def compress(self, path, filename=None):
        super(PristineSource, self).compress(path, filename)

    def remove(self):
        super(PristineSource, self).remove()

    def run_script(self, script):
        super(PristineSource, self).run_script(script)
