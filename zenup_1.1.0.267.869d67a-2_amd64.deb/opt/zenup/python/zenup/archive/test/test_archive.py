##############################################################################
#
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
#
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
#
##############################################################################

import unittest
from mockito import mock, when, verify

from zenup.archive import Archive, ArchiveError


class TestArchive(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_open(self):
        import os
        import shutil
        import tarfile
        import tempfile
        import yaml

        resource = "/path/to/success"
        when(os.path).exists(resource).thenReturn(True)
        when(os).access(resource, os.R_OK).thenReturn(True)
        when(tarfile).is_tarfile(resource).thenReturn(True)

        config = {"version":345}
        tar = mock(tarfile.TarFile)
        when(tar).getnames().thenReturn(["config.yaml"])
        when(tar).extractfile("config.yaml").thenReturn(config)
        when(yaml).load(config).thenReturn(config)
        when(tarfile).open(resource).thenReturn(tar)

        basename = os.path.basename(resource) + "_"
        outpath = os.path.join("/tmp", basename + "TEST")
        when(tempfile).mkdtemp(prefix=basename, dir=None).thenReturn(outpath)
        when(tar).extractall(path=outpath).thenReturn(None)
        
        when(shutil).rmtree(outpath).thenReturn(None)

        with Archive.extract(resource) as archive:
            self.assertEqual(archive.resource, resource)
            self.assertEqual(archive.path, outpath)
            self.assertEqual(archive.config.type, None)
            self.assertEqual(archive.config.version, config["version"])

    def test_load(self):
        import os
        import tarfile
        import yaml

        # Path not exist
        resource = "/some/fake/path"
        when(os.path).exists(resource).thenReturn(False)
        self.assertRaises(ArchiveError, Archive.load, resource)

        # Path no read
        resource = "/path/no/read"
        when(os.path).exists(resource).thenReturn(True)
        when(os).access(resource, os.R_OK).thenReturn(False)
        self.assertRaises(ArchiveError, Archive.load, resource)

        # Path not tarfile
        resource = "/path/not/tarfile"
        when(os.path).exists(resource).thenReturn(True)
        when(os).access(resource, os.R_OK).thenReturn(True)
        when(tarfile).is_tarfile(resource).thenReturn(False)
        self.assertRaises(ArchiveError, Archive.load, resource)

        # Tarfile raises error
        resource = "/path/fails/to/open/as/tar"
        when(os.path).exists(resource).thenReturn(True)
        when(os).access(resource, os.R_OK).thenReturn(True)
        when(tarfile).is_tarfile(resource).thenReturn(True)
        when(tarfile).open(resource).thenRaise(tarfile.TarError())
        self.assertRaises(ArchiveError, Archive.load, resource)

        # Archive is not valid
        resource = "/archive/is/not/valid"
        tar = mock(tarfile.TarFile)
        when(tar).getnames().thenReturn(["folder","file1","file2"])

        when(os.path).exists(resource).thenReturn(True)
        when(os).access(resource, os.R_OK).thenReturn(True)
        when(tarfile).is_tarfile(resource).thenReturn(True)
        when(tarfile).open(resource).thenReturn(tar)
        self.assertRaises(ArchiveError, Archive.load, resource)

        # configure raises TarError
        resource = "/archive/does/not/configure"
        tar = mock(tarfile.TarFile)
        when(tar).getnames().thenReturn(["config.yaml", "file1", "file2"])
        when(tar).extractfile("config.yaml").thenRaise(tarfile.TarError())

        when(os.path).exists(resource).thenReturn(True)
        when(os).access(resource, os.R_OK).thenReturn(True)
        when(tarfile).is_tarfile(resource).thenReturn(True)
        when(tarfile).open(resource).thenReturn(tar)
        self.assertRaises(ArchiveError, Archive.load, resource)

        # success
        config = {"version": 564}
        resource = "/path/to/success"
        tar = mock(tarfile.TarFile)
        when(tar).getnames().thenReturn(["config.yaml"])
        when(tar).extractfile("config.yaml").thenReturn(config)

        when(yaml).load(config).thenReturn(config)
        
        when(os.path).exists(resource).thenReturn(True)
        when(os).access(resource, os.R_OK).thenReturn(True)
        when(tarfile).is_tarfile(resource).thenReturn(True)
        when(tarfile).open(resource).thenReturn(tar)
        archive = Archive.load(resource)
        self.assertEqual(archive.config.type, None)
        self.assertEqual(archive.config.version, config["version"])

    def test_configure(self):
        import yaml
        import tarfile

        config = {"version": 999}
        tar = mock(tarfile.TarFile)
        when(tar).extractfile("config.yaml").thenReturn(config)
        when(yaml).load(config).thenReturn(config)
        
        archive = Archive(None)
        archive.configure(tar)
        self.assertEqual(archive.config.type, None)
        self.assertEqual(archive.config.version, 999)

    def test_extract(self):
        import os
        import shutil
        import tarfile
        import tempfile
        import yaml

        # Archive already open
        archive = Archive(None)
        archive.path = "/some/fake/path"
        self.assertRaises(ArchiveError, archive.extract)
        self.assertRaises(ArchiveError, archive.extract, "/some/other/fake")
        
        # Extract path specified
        
        ## Path does not exist
        resource = "/resource/for/path"
        path = "/path/not/exist"
        when(os.path).exists(path).thenReturn(False)
        archive = Archive(resource)
        self.assertRaises(ArchiveError, archive.extract, path)

        ## Path is not a directory
        path = "/path/not/directory"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(False)
        archive = Archive(resource)
        self.assertRaises(ArchiveError, archive.extract, path)

        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.W_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(True)
        archive = Archive(resource)
        self.assertRaises(ArchiveError, archive.extract, path)

        ## Path no read perm
        path = "/path/no/read"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(False)
        when(os).access(path, os.W_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(True)
        archive = Archive(resource)
        self.assertRaises(ArchiveError, archive.extract, path)

        ## Path no write perm
        path = "/path/no/write"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.W_OK).thenReturn(False)
        when(os).access(path, os.X_OK).thenReturn(True)
        archive = Archive(resource)
        self.assertRaises(ArchiveError, archive.extract, path)

        ## Path no exec perm
        path = "/path/no/exec"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.W_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(False)
        archive = Archive(resource)
        self.assertRaises(ArchiveError, archive.extract, path)

        # Raise TarError while extracting
        path = "/path/to/success"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.W_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(True)

        config = {"version": 999}
        tar = mock(tarfile.TarFile)
        when(tar).getnames().thenReturn(["config.yaml"])
        when(tar).extractfile("config.yaml").thenReturn(config)

        when(yaml).load(config).thenReturn(config)
        
        resource = "/resource/raises/tarfile"
        when(os.path).exists(resource).thenReturn(True)
        when(os).access(resource, os.R_OK).thenReturn(True)
        when(tarfile).is_tarfile(resource).thenReturn(True)
        when(tarfile).open(resource).thenReturn(tar)

        basename = os.path.basename(resource) + "_"
        outpath = os.path.join(path, basename + "TEST")
        when(tempfile).mkdtemp(prefix=basename, dir=path).thenReturn(outpath)
        when(tar).extractall(path=outpath).thenRaise(tarfile.TarError())

        archive = Archive(resource)
        self.assertRaises(ArchiveError, archive.extract, path)
        verify(tempfile).mkdtemp(prefix=basename, dir=path)
        verify(tar).extractall(path=outpath)

        # Success
        resource = "/resource/is/tgz"
        when(os.path).exists(resource).thenReturn(True)
        when(os).access(resource, os.R_OK).thenReturn(True)
        when(tarfile).is_tarfile(resource).thenReturn(True)
        when(tarfile).open(resource).thenReturn(tar)

        basename = os.path.basename(resource) + "_"
        outpath = os.path.join(path, basename + "TEST")
        when(tempfile).mkdtemp(prefix=basename, dir=path).thenReturn(outpath)
        when(tar).extractall(path=outpath).thenReturn(None)
        when(shutil).rmtree(outpath).thenReturn(None)
        
        archive = Archive(resource)
        archive.extract(path)
        self.assertEqual(archive.resource, resource)
        self.assertEqual(archive.path, outpath)
        self.assertEqual(archive.config.type, None)
        self.assertEqual(archive.config.version, 999)      
        verify(tempfile).mkdtemp(prefix=basename, dir=path)
        verify(tar).extractall(path=outpath)

        archive.remove()
        self.assertEqual(archive.resource, resource)
        self.assertEqual(archive.path, None)
        self.assertEqual(archive.config.type, None)
        self.assertEqual(archive.config.version, 999)

        outpath = os.path.join("/tmp", basename + "TEST")
        when(tempfile).mkdtemp(prefix=basename, dir=None).thenReturn(outpath)
        when(tar).extractall(path=outpath).thenReturn(None)

        archive.extract()
        self.assertEqual(archive.resource, resource)
        self.assertEqual(archive.path, outpath)
        self.assertEqual(archive.config.type, None)
        self.assertEqual(archive.config.version, 999)
        verify(tempfile).mkdtemp(prefix=basename, dir=None)
        verify(tar).extractall(path=outpath)

    def test_compress(self):
        import os
        import tarfile

        # Compress a closed path
        resource = "/path/to/resource"
        archive = Archive(resource)
        self.assertRaises(ArchiveError, archive.compress, "/some/fake/path")
        archive.path = "/where/i/live"
        ls = ["file1","file2","file3","dir1","dir2"]
        when(os).listdir(archive.path).thenReturn(ls)
        
        # No perms

        ## Path doesn't exist
        path = "/path/no/exist"
        when(os.path).exists(path).thenReturn(False)
        self.assertRaises(ArchiveError, archive.compress, path)

        ## Path is not a dir
        path = "path/not/dir"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(False)
        self.assertRaises(ArchiveError, archive.compress, path)

        ## Path is no access
        path = "path/not/readable"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(False)
        when(os).access(path, os.W_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(True)
        self.assertRaises(ArchiveError, archive.compress, path)
        
        path = "path/not/writeable"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.W_OK).thenReturn(False)
        when(os).access(path, os.X_OK).thenReturn(True)
        self.assertRaises(ArchiveError, archive.compress, path)

        path = "path/not/executable"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.W_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(False)
        self.assertRaises(ArchiveError, archive.compress, path)

        # Tar exists
        path = "path/to/existance"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.W_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(True)

        ## WITH file name
        filename = "custom_filename"
        fullpath = os.path.join(path, filename)
        when(os.path).exists(fullpath).thenReturn(True)
        self.assertRaises(ArchiveError, archive.compress, path, filename=filename)
        verify(os.path).exists(fullpath)

        ## WITHOUT file name
        fullpath = os.path.join(path, os.path.basename(resource))
        when(os.path).exists(fullpath).thenReturn(True)
        self.assertRaises(ArchiveError, archive.compress, path)
        verify(os.path).exists(fullpath)

        # TarError
        path = "/path/to/success"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.W_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(True)

        filename = "custom_filename"
        fullpath = os.path.join(path, filename)
        when(os.path).exists(fullpath).thenReturn(False)
        when(tarfile).open(fullpath, "w:gz").thenRaise(tarfile.TarError())
        self.assertRaises(ArchiveError, archive.compress, path, filename=filename)
        verify(os.path).exists(fullpath)
        verify(tarfile).open(fullpath, "w:gz")

        filename = "custom_filename_2"
        fullpath = os.path.join(path, filename)
        when(os.path).exists(fullpath).thenReturn(False)
        tar = mock(tarfile.TarFile)
        when(tar).add(os.path.join(archive.path, ls[0]), arcname=ls[0])\
            .thenRaise(tarfile.TarError)
        when(tarfile).open(fullpath, "w:gz").thenReturn(tar)
        self.assertRaises(ArchiveError, archive.compress, path, filename=filename)
        verify(os.path).exists(fullpath)
        verify(tarfile).open(fullpath, "w:gz")
        verify(tar).add(os.path.join(archive.path, ls[0]), arcname=ls[0])
        
        # Success
        ls.pop(0)
        for i in ls:
            when(tar).add(os.path.join(archive.path, i), arcname=i).thenReturn(None)
        archive.compress(path, filename=filename)

    def test_remove(self):
        import shutil
        
        archive = Archive(None)
        self.assertRaises(ArchiveError, archive.remove)
        archive.path = "/path/to/archive"
        when(shutil).rmtree(archive.path).thenReturn(None)
        archive.remove() 

    def test_run_script(self):
        import os
        import subprocess

        # Archive not open
        resource = "/path/to/resource"
        archive = Archive(resource)
        self.assertRaises(ArchiveError, archive.run_script, None)

        # Script not valid
        archive.path = "/path/to/open/archive"
        self.assertRaises(ArchiveError, archive.run_script, None)

        # Script not found
        script = "not_exist"
        path = os.path.join(archive.path, script)
        when(os.path).exists(path).thenReturn(False)
        archive.run_script(script)

        # Script no access

        ## Script not file
        script = "not_file"
        path = os.path.join(archive.path, script)
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isfile(path).thenReturn(False)
        self.assertRaises(ArchiveError, archive.run_script, script)

        ## Script not readable
        script = "not_readable"
        path = os.path.join(archive.path, script)
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isfile(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(False)
        when(os).access(path, os.X_OK).thenReturn(True)
        self.assertRaises(ArchiveError, archive.run_script, script)

        ## Script not executable
        script = "not_executable"
        path = os.path.join(archive.path, script)
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isfile(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(False)
        self.assertRaises(ArchiveError, archive.run_script, script)

        # Script unsuccessful
        stdout = mock()
        when(stdout).readline().thenReturn("")

        script = "nonzero"
        path = os.path.join(archive.path, script)
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isfile(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(True)

        popen = mock()
        popen.stdout = stdout
        when(popen).wait().thenReturn(None)
        popen.returncode = 1
        when(subprocess).Popen(path, stdout=subprocess.PIPE, 
            stderr=subprocess.STDOUT, shell=True).thenReturn(popen)
        self.assertRaises(ArchiveError, archive.run_script, script)
        verify(popen).wait()

        # Script successful
        script = "success"
        path = os.path.join(archive.path, script)
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isfile(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(True)
        
        popen = mock()
        popen.stdout = stdout
        when(popen).wait().thenReturn(None)
        popen.returncode = 0
        when(subprocess).Popen(path, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, shell=True).thenReturn(popen)
        archive.run_script(script)
        verify(popen).wait()
