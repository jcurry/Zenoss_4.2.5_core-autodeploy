##############################################################################
#
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
#
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
#
##############################################################################

import unittest
from mockito import when, mock, verify, never, spy
from mockito import any as mock_any

from zenup.archive import ArchiveError, Archive
from zenup.archive.zup import ZupArchive, ZupArchiveError
from zenup.config.zup import ZupConfiguration
from zenup.config.hotfix import HotfixConfiguration


class TestZupArchive(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    # def test_lifecycleScripts(self):
    #     import yaml, tarfile, os
    #
    #     tar = mock(tarfile.TarFile)
    #     manifest = {"fixes": [{"id": "patch0",
    #                            "description": "description",
    #                            "patches": ["patch0"]
    #                           }],}
    #     when(tar).extractfile("./manifest.yaml").thenReturn(manifest)
    #     when(yaml).load(manifest).thenReturn(manifest)
    #     config = {"revision": "10",
    #               "created": "createdate",
    #               "product": "testproduct",
    #               "rps": "20",
    #               "type": ZupConfiguration.TYPE,
    #               "pre": ["pre/pre1"],
    #               "check": [],
    #               "post": ["post/post1", "post/post2"]}
    #     when(tar).extractfile("./config.yaml").thenReturn(config)
    #     when(yaml).load(config).thenReturn(config)
    #     zup = ZupArchive("myZup")
    #     zup_spy = spy(zup)
    #     zup_spy.configure(tar)
    #
    #     self.assertRaisesRegexp(ArchiveError, "Resource not open!", zup_spy.run_scripts, "pre")
    #     #verify(zup_spy, times=1).run_script("pre/pre1")
    #     zup_spy.run_scripts("check")
    #     self.assertRaises(KeyError, zup_spy.run_scripts, None)
    #     when(ZupArchive).is_open().thenReturn(True)
    #     when(os.path).join(None, mock_any(str)).thenReturn("/path/to/script")
    #     zup_spy.run_scripts("post")
    #     #verify(zup_spy, times=2).run_scripts(mock_any(str))

    def test_configure(self):
        import yaml
        import tarfile

        tar = mock(tarfile.TarFile)

        manifest = {
            "fixes": [{"id": "patch0",
                       "description": "description",
                       "patches": ["patch0"]
                      }],
            "patches": ["patch0"],
            "changes": {"patch0": {"adds": ["file1"], "modifies": [], "deletes": []}
            },
        }
        when(tar).extractfile("./manifest.yaml").thenReturn(manifest)
        when(yaml).load(manifest).thenReturn(manifest)

        config = {"revision": "10",
                  "created": "createdate",
                  "product": "testproduct",
                  "customer": "customer",
                  "rps": "20",
                  "check": [],
                  "pre": [],
                  "post": [],
                  }

        when(tar).extractfile("./config.yaml").thenReturn(config)
        when(yaml).load(config).thenReturn(config)

        # RPS
        config["type"] = ZupConfiguration.TYPE
        rps = ZupArchive("rps resource")
        rps.configure(tar)
        self.assertTrue(rps.is_rps())
        self.assertFalse(rps.is_hotfix())

        # Hotfix
        config["type"] = HotfixConfiguration.TYPE
        hotfix = ZupArchive("hotfix resource")
        hotfix.configure(tar)
        self.assertTrue(hotfix.is_hotfix())
        self.assertFalse(hotfix.is_rps())

        # Neither
        config["type"] = "badtype"
        neither = ZupArchive("neither resource")
        self.assertRaises(ZupArchiveError, neither.configure, tar)

    def test_apply_patches(self):
        import os
        import shutil
        from zenup.archive import zup
        from zenup.config.zup import Manifest, ManifestFix, ManifestChange
        from zenup import utils

        resource = "/path/to/resource"
        archive = ZupArchive(resource)

        # Archive not open
        gen = archive.apply_patches("/some/fake/path")
        self.assertRaises(ArchiveError, gen.next)

        cwd = "/current/working/dir"
        archive.path = "/path/to/environment"
        when(os).getcwd().thenReturn(cwd)
        when(os).chdir(cwd).thenReturn(None)

        # Path validation

        ## Path does not exist
        path = "/path/not/exist"
        when(os.path).exists(path).thenReturn(False)
        gen = archive.apply_patches(path)
        self.assertRaises(ArchiveError, gen.next)

        ## Path is not a directory
        path = "/path/not/dir"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(False)
        gen = archive.apply_patches(path)
        self.assertRaises(ArchiveError, gen.next)

        ## Path is not readable
        path = "/path/not/readable"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(False)
        when(os).access(path, os.W_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(True)
        gen = archive.apply_patches(path)
        self.assertRaises(ArchiveError, gen.next)

        ## Path is not writeable
        path = "/path/not/writeable"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.W_OK).thenReturn(False)
        when(os).access(path, os.X_OK).thenReturn(True)
        gen = archive.apply_patches(path)
        self.assertRaises(ArchiveError, gen.next)

        ## Path is not executable
        path = "/path/not/executable"
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.W_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(False)
        gen = archive.apply_patches(path)
        self.assertRaises(ArchiveError, gen.next)

        # Manifest validation
        path = "/path/to/success"
        when(os).chdir(path).thenReturn(None)
        when(os.path).exists(path).thenReturn(True)
        when(os.path).isdir(path).thenReturn(True)
        when(os).access(path, os.R_OK).thenReturn(True)
        when(os).access(path, os.W_OK).thenReturn(True)
        when(os).access(path, os.X_OK).thenReturn(True)

        ## Patch not in manifest
        manifest = mock(Manifest)
        manifest.patches = ["patch1"]
        manifest.changes = {}
        archive.manifest = manifest
        gen = archive.apply_patches(path)
        self.assertRaises(ZupArchiveError, gen.next)
        verify(os).chdir(path)
        verify(os).chdir(cwd)

        ## Patch not in archive
        change = mock(ManifestChange)
        change.adds = []
        change.deletes = []
        change.modifies = []
        manifest.changes["patch1"] = change
        when(os.path).isfile(os.path.join(archive.patches_path(), "patch1")) \
            .thenReturn(False)
        gen = archive.apply_patches(path)
        self.assertRaises(ZupArchiveError, gen.next)
        verify(os, times=2).chdir(path)
        verify(os, times=2).chdir(cwd)
        verify(os.path).isfile(os.path.join(archive.patches_path(), "patch1"))

        # Patching

        ## Exit code 1
        patch = "patch1"
        manifest.patches = [patch]
        manifest.changes[patch] = change
        patchpath = os.path.join(archive.patches_path(), patch)

        fp = mock()
        when(fp).close().thenReturn(None)
        retval = (utils.PATCH_WARN, "stdout", "stderr",)

        when(os.path).isfile(patchpath).thenReturn(True)
        when(utils).fileopen(patchpath, "r").thenReturn(fp)
        when(utils).patch(fp, "-p0").thenReturn(retval)
        gen = archive.apply_patches(path)
        self.assertRaisesRegexp(ZupArchiveError, "stdout", gen.next)
        verify(os, times=3).chdir(path)
        verify(os, times=3).chdir(cwd)

        ## Exit code 2
        patch = "patch2"
        manifest.patches = [patch]
        manifest.changes[patch] = change
        patchpath = os.path.join(archive.patches_path(), patch)

        fp = mock()
        when(fp).close().thenReturn(None)
        retval = (utils.PATCH_ERROR, "stdout", "stderr",)

        when(os.path).isfile(patchpath).thenReturn(True)
        when(utils).fileopen(patchpath, "r").thenReturn(fp)
        when(utils).patch(fp, "-p0").thenReturn(retval)
        gen = archive.apply_patches(path)
        self.assertRaisesRegexp(ZupArchiveError, "stderr", gen.next)
        verify(os, times=4).chdir(path)
        verify(os, times=4).chdir(cwd)

        ## Cannot delete path
        patch = "patch_success"
        manifest.patches = [patch]
        manifest.changes[patch] = change
        patchpath = os.path.join(archive.patches_path(), patch)

        fp = mock()
        when(fp).close().thenReturn(None)
        retval = (utils.PATCH_OK, "stdout", "stderr",)

        when(os.path).isfile(patchpath).thenReturn(True)
        when(utils).fileopen(patchpath, "r").thenReturn(fp)
        when(utils).patch(fp, "-p0").thenReturn(retval)

        change.deletes = ["delete_file", "path/to/delete_dir", "cannot_delete"]

        when(os.path).isfile(change.deletes[0]).thenReturn(True)
        when(os.path).isdir(change.deletes[0]).thenReturn(False)
        when(os).remove(change.deletes[0]).thenReturn(None)
        when(shutil).rmtree(change.deletes[0]).thenReturn(None)
        when(os.path).isfile(change.deletes[1]).thenReturn(False)
        when(os.path).isdir(change.deletes[1]).thenReturn(True)
        when(os).remove(change.deletes[1]).thenReturn(None)
        when(shutil).rmtree(change.deletes[1]).thenReturn(None)
        when(os.path).isfile(change.deletes[2]).thenReturn(False)
        when(os.path).isdir(change.deletes[2]).thenReturn(False)
        when(os).remove(change.deletes[2]).thenReturn(None)
        when(shutil).rmtree(change.deletes[2]).thenReturn(None)

        gen = archive.apply_patches(path)
        self.assertRaises(ZupArchiveError, gen.next)
        verify(shutil, never).rmtree(change.deletes[0])
        verify(os, never).remove(change.deletes[1])
        verify(shutil, never).rmtree(change.deletes[2])
        verify(os, never).remove(change.deletes[2])

        # Success
        change.deletes = []
        gen = archive.apply_patches(path)
        patchname = gen.next()
        self.assertEqual(patchname, patch)

