##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################

import os
import logging
import shutil
import yaml

from zenup.archive import ArchiveError, Archive
from zenup.config.zup import ZupConfiguration, Manifest
from zenup.config.hotfix import HotfixConfiguration
from zenup import utils, ZenUpException

auditLogger = logging.getLogger("audit")

class ZupArchiveError(ArchiveError):
    pass

class ZupArchive(Archive):
    """
    Class that loads data about a zup
    """
    
    _file_structure = ["./config.yaml",
                       "./manifest.yaml"]
    _config = [("manifest", "./manifest.yaml", Manifest),]

    @classmethod
    def load(cls, resource, respect_config_validity=True):
        """
        Loads configuration data pertaining to a ZenUp Archive.

        @param resource: path to the resource
        @returns Archive
        """
        obj = cls(resource)
        with obj.safeopen(): pass
        if respect_config_validity and not obj.config.valid:
            raise ZenUpException("Archive config is not valid! (%s)" % resource)
        return obj

    def __init__(self, resource):
        super(ZupArchive, self).__init__(resource)
        self.manifest = None

    def is_rps(self):
        return self.config.TYPE == ZupConfiguration.TYPE

    def is_hotfix(self):
        return self.config.TYPE == HotfixConfiguration.TYPE
  
    def configure(self, tar):
        super(ZupArchive, self).configure(tar)

        fp = tar.extractfile('./config.yaml')
        config = yaml.load(fp)
        type = config.get('type')

        if   type == ZupConfiguration.TYPE:
            self.config = ZupConfiguration(config)
        elif type == HotfixConfiguration.TYPE:
            self.config = HotfixConfiguration(config)
        else:
            raise ZupArchiveError("Unknown zup type: %s" % type)
        
    def patches_path(self):
        return os.path.join(self.path, "patches")

    def compress(self, path, filename=None):
        super(ZupArchive, self).compress(path, filename)

    def remove(self):
        super(ZupArchive, self).remove()

    def run_script(self, script):
        super(ZupArchive, self).run_script(script)

    def apply_patches(self, path):
        """
        Returns a generator that reads the manifest and applies patches
        related to a zup.

        @param path: path where the patches will be applied
        @yields string (name of the patch file)
        @raises ZupArchiveError
        """
        
        if not self.is_open():
            raise ArchiveError("Resource not open!")
        elif not os.path.exists(path) or \
             not os.path.isdir(path) or \
             not os.access(path, os.R_OK) or \
             not os.access(path, os.W_OK) or \
             not os.access(path, os.X_OK):
            raise ZupArchiveError("Cannot apply patches to path")

        cwd = os.getcwd()
        try:
            os.chdir(path)
            for patch in self.manifest.patches:
                p = os.path.join(self.patches_path(), patch)
                if patch not in self.manifest.changes:
                    raise ZupArchiveError("Missing metadata for patch %s" % patch)
                elif not os.path.isfile(p):
                    raise ZupArchiveError("Patch %s not found in resource" % patch)

                fp = None
                try:
                    fp = utils.fileopen(p, "r")
                    output, stdout, stderr = utils.patch(fp, "-p0")
                    if output == utils.PATCH_WARN:
                        raise ZupArchiveError(stdout)
                    elif output == utils.PATCH_ERROR:
                        raise ZupArchiveError(stderr)
                finally:
                    if fp:
                        try:
                            fp.close()
                        except Exception: pass

                for deleted in self.manifest.changes[patch].deletes:
                    if os.path.isfile(deleted):
                        os.remove(deleted)
                    elif os.path.isdir(deleted):
                        shutil.rmtree(deleted)
                    else:
                        raise ZupArchiveError("Cannot delete path %s" % deleted)

                yield patch
        finally:
            os.chdir(cwd)
