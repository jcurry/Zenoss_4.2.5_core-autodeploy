import logging
from zenup import ZenUpManualRotatingFileHandler

auditLogger = logging.getLogger("audit")

def getAuditLogHandler():
    for handler in auditLogger.handlers:
        if isinstance(handler, ZenUpManualRotatingFileHandler):
            return handler