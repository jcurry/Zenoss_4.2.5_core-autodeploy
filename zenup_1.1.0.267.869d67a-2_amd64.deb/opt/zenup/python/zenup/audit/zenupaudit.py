import re
import logging
from zenup.audit import getAuditLogHandler

logger = logging.getLogger("zenup")

class ZenUpAudit(object):

    def __init__(self):
        self.completedLifecycleSteps = []
        auditFilePath = getAuditLogHandler().baseFilename
        with open(auditFilePath, "r") as auditLogFile:
            for line in auditLogFile:
                regex = ".*END\s{4}:\s(?P<lifecycleStep>.*)"
                matcher = re.match(regex, line)
                if matcher:
                    self.completedLifecycleSteps.append(matcher.group("lifecycleStep"))

    def stepCompleted(self, lifecycleStep):
        return lifecycleStep in self.completedLifecycleSteps

    def getLastAttempted(self):
        if getAuditLogHandler().isLogEmpty():
            return None
        auditFilePath = getAuditLogHandler().baseFilename
        with open(auditFilePath, "r") as auditLogFile:
            curr_begin = ""
            curr_end = ""
            beginRegex = ".*BEGIN\s{2}:\s(?P<beginLifecycleStep>.*)"
            endRegex = ".*END\s{4}:\s(?P<endLifecycleStep>.*)"
            beginSeen = []
            endSeen = []
            for line in auditLogFile:
                matcher = re.match(beginRegex, line)
                if matcher and matcher.group("beginLifecycleStep") not in beginSeen:
                    curr_begin = matcher.group("beginLifecycleStep")
                    beginSeen.append(curr_begin)
                    continue
                matcher = re.match(endRegex, line)
                if matcher and matcher.group("endLifecycleStep") not in endSeen:
                    curr_end = matcher.group("endLifecycleStep")
                    endSeen.append(curr_end)

        if curr_begin != curr_end:
            return curr_begin
