ZenUp Configuration
===

ZenUp uses [YAML](http://www.yaml.org) to load information stored within an archive.  The *Configuration* object provides a simplified way of loading these configurations, validating them, and parsing them into an object that is easy to use.  There can also be additional subclasses of the Configuration object based on the format of the data provided.  YAMLConfiguration, for instance, parses these YAML resources.

## Version
1.0

Implementation
---

So let's say we have a YAML file that we need to  load and validate:

```yaml

	---
	type: example
	textvalue: some data here
	intvalue: 100
	
```

To create a new *Configuration* type, initialize your class with either a given resource (file-like object) or a configuration (dictionary object).  Then, call the super class method given the specific object type.

```python

	from zenup.config import YAMLConfiguration

	class MyConfiguration(YAMLConfiguration):
		TYPE = "example"

    	def __init__(self, resource):
    	    super(MyConfiguration, self).__init__(resource)
```    

Now, we need to add attributes to be validated.  The super class initializes the resulting information in a dictionary object `self.config`. You will then create methods (prefixed with '_') that are decorated with these validators.  The `__init__` method will compute the value from these methods and load the result into a class attribute.

```python

		@require(name="textvalue")
		def _text(self):
			return self.config.get("textvalue")

		@intvalue(name="intvalue", minval=10)
		def _number(self):
			return self.config.get("intvalue")
```

When this class is instantiated, if the value of the key "textvalue" in `self.config` is not None, then the class will contain an attribute "text", with the value of `self.config['textvalue']`.

```python

	>>> config = MyConfiguration(myresource)
	>>> print config.text
	some data here
	>>> print config.number
	100
```

### Validators

- require
- equal
- intvalue
- default
- listify
- path
- cast

Inheritance
---
Refer to the python docstrings for more information

### ProductConfiguration
Loads information about a zenup product.  This data is stored in $ZENUPHOME/var/status.yaml

### SourceConfiguration
Loads information stored on the config.yaml file of the pristine source.

### ZupConfiguration
Loads information stored on the config.yaml file of the zup.

### Manifest
Loads information stored on the manifest.yaml file of the zup

### ManifestFix
A subset of the data stored on the Manifest pertaining to fixes

### Manifest Change
A subset of the data stored on the Manifest pertaining to files affected by a particular patch.
