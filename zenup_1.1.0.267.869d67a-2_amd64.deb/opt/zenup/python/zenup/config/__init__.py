##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################

import yaml
import os

VALIDATOR_FLAG = "_VALIDATE"
PREFIX = "_"

FORMAT_YAML = "YAML"
FORMAT_JSON = "JSON"
FORMAT_XML  = "XML"

class ConfigurationError(AttributeError):
    pass

class require(object):
    """
    Validation decorator that checks for the existance of an attribute.

    @param name: name of the attribute being checked
    @param criteria: custom function that validates the value of a method
    @param emptyOK: flag that indicates whether to accept empty value objects
        as opposed to only non-NoneType objects
    @returns object
    @raises ConfigurationError
    """

    def __init__(self, criteria=None, name=None, emptyOK=True):
       self.name = name
       self.criteria = criteria
       self.emptyOK = emptyOK

    def __call__(self, f):
        attribute = (self.name or f.__name__).upper()
        def inner(*args, **kwargs):
            value = f(*args, **kwargs)
            if self.emptyOK and value is None:
                raise ConfigurationError("Attribute required %s" % attribute)
            elif not self.emptyOK and not value:
                raise ConfigurationError("Attribute %s must have a value" % attribute)

            if self.criteria and not self.criteria(value):
                raise ConfigurationError("Invalid attribute value %s" % attribute)
            return value
        setattr(inner, VALIDATOR_FLAG, True)
        return inner


class equal(object):
    """
    Validation decorator that checks that resulting object satisfies the
    equality operator with another object.

    @param name: name of the attribute being checked
    @param obj: object to compare
    @returns object
    @raises ConfigurationError
    """

    def __init__(self, obj, name=None):
        self.obj = obj
        self.name = name

    def __call__(self, f):
        attribute = (self.name or f.__name__).upper()
        def inner(*args, **kwargs):
            value = f(*args, **kwargs)
            if value != self.obj:
                raise ConfigurationError("Unexpected attribute value %s "
                                     "(expected: '%s'; actual '%s')" %
                                     (attribute, str(self.obj), value))
            return value
        setattr(inner, VALIDATOR_FLAG, True)
        return inner


class intvalue(object):
    """
    Validation decorator that verifies that the resulting object can be
    parsed as an integer.

    @param name: name of the attribute being checked
    @param minval: minimum value requirement (inclusive)
    @param maxval: maximum value requirement (inclusive)
    @returns integer
    @raises ConfigurationError
    """

    def __init__(self, minval=None, maxval=None, name=None):
        self.minval = minval
        self.maxval = maxval
        self.name = name

    def __call__(self, f):
        attribute = (self.name or f.__name__).upper()
        def inner(*args, **kwargs):
            try:
                value = int(f(*args, **kwargs))
                minbounds = self.minval is None or value >= self.minval
                maxbounds = self.maxval is None or value <= self.maxval
                if not (minbounds and maxbounds):
                    raise ConfigurationError("Attribute %s is out of bounds" % attribute)
            except (TypeError, ValueError) as e:
                raise ConfigurationError("Attribute %s must have an integer "
                                         "value" % attribute)
            return value
        setattr(inner, VALIDATOR_FLAG, True)
        return inner


class default(object):
    """
    Validator decorator that returns a default value if the resulting value is
    a NoneType object

    @param obj: Resulting object to default to
    @returns object
    """

    def __init__(self, obj):
        self.obj = obj

    def __call__(self, f):
        def inner(*args, **kwargs):
            value = f(*args, **kwargs)
            if value is None:
                return self.obj
            return value
        setattr(inner, VALIDATOR_FLAG, True)
        return inner


class listify(object):
    """
    Validator decorator that transforms the resulting object into a list.  If a
    value is already an iterable and not a dictionary, cast that object as a
    list type, otherwise wrap the result in a list object.

    @returns list
    """

    def __init__(self):
        pass

    def __call__(self, f):
        def inner(*args, **kwargs):
            value = f(*args, **kwargs)
            if not value and (value is None or isinstance(value, basestring)):
                return []
            elif isinstance(value, list):
                return value
            elif hasattr(value, "__iter__") and not isinstance(value, dict):
                return list(value)
            else:
                return [value]
        setattr(inner, VALIDATOR_FLAG, True)
        return inner

class path(object):
    """
    Validator decorator that checks if the object value exists in the file
    system.

    @param name: name of the attribute being checked
    @param dir: boolean flag that, if true, requires a path to be a directory
    @param file: boolean flag that, if true, requires a path to be a file
    @param rOK: boolean flag that, if true, requires a path for read access
    @param wOK: boolean flag that, if true, requires a path for write access
    @param xOK: boolean flag that, if true, requires a path for exec access
    @returns absolute path
    @raises ConfigurationError
    """
    
    def __init__(self, name=None, dir=None, file=None, rOK=None, wOK=None, 
                 xOK=None):
        self.name = name
        self.dir = dir
        self.file = file
        self.rOK = rOK
        self.wOK = wOK
        self.xOK = xOK

    def __call__(self, f):
        attribute = (self.name or f.__name__).upper()
        msg = "Attribute %s must %sbe %s"

        def inner(*args, **kwargs):
            value = f(*args, **kwargs)
            if not value:
                raise ConfigurationError("Attribute %s required" % attribute)

            value = os.path.abspath(value)
            if not os.path.exists(value):
                raise ConfigurationError("Attribute %s is not a real path" % attribute)
            elif self.dir is not None:
                prefix = not self.dir and "NOT " or ""
                keyword = "a directory"
                if self.dir != os.path.isdir(value):
                    raise ConfigurationError(msg % (attribute, prefix, keyword))
            elif self.file is not None:
                prefix = not self.file and "NOT " or ""
                keyword = "a file"
                if self.file != os.path.isfile(value):
                    raise ConfigurationError(msg % (attribute, prefix, keyword))
            elif self.rOK is not None:
                prefix = not self.rOK and "NOT " or ""
                keyword = "readable"
                if self.rOK != os.access(value, os.R_OK):
                    raise ConfigurationError(msg % (attribute, prefix, keyword))
            elif self.wOK is not None:
                prefix = not self.wOK and "NOT " or ""
                keyword = "writeable"
                if self.wOK != os.access(value, os.W_OK):
                    raise ConfigurationError(msg % (attribute, prefix, keyword))
            elif self.xOK is not None:
                prefix = not self.xOK and "NOT " or ""
                keyword = "executable"
                if self.xOK != os.access(value, os.X_OK):
                    raise ConfigurationError(msg % (attribute, prefix, keyword))
            return value
        setattr(inner, VALIDATOR_FLAG, True)
        return inner


class cast(object):
    """
    Validator decorator that casts an object as a type specified.

    @param cls: Class or function for which to transform the object
    @returns object
    """

    def __init__(self, cls):
        self.cls = cls

    def __call__(self, f):
        def inner(*args, **kwargs):
            return self.cls(f(*args, **kwargs))
        setattr(inner, VALIDATOR_FLAG, True)
        return inner

            
class Configuration(object):
    """
    Object that loads, parses, and validates dictionary-like objects given a
    specific template, as specified by the inherited object.
    """
    
    TYPE = None

    def __init__(self, config):
        self.config = config
        self._validate()
        delattr(self, "config")

    def __getitem__(self, item):
        return self.__dict__[item]

    def _validate(self):
        """
        Looks up all of the methods on the object.  If method has a validator
        flag on the object, will save the result of the method as a class
        attribute.
        """

        if not isinstance(self.config, dict):
            raise ConfigurationError("Resource is not a valid configuration!")
        
        for methodName in dir(self):
            methodCall = getattr(self, methodName)
            if getattr(methodCall, VALIDATOR_FLAG, False):
                setattr(self, methodName.replace(PREFIX, "", 1), methodCall())
        
    @default(None)
    def _type(self):

        @equal(self.TYPE, name="type")
        def f():
            return self.config.get("type")
        return f()

    @default(0)
    def _version(self):
        return self.config.get("version")

    @classmethod
    def load(cls, resource, format=FORMAT_YAML):
        if   format == FORMAT_YAML:
            return cls.loadYAML(resource)
        elif format == FORMAT_JSON:
            return cls.loadJSON(resource)
        elif format == FORMAT_XML:
            return cls.loadXML(resource)
        else:
            raise ConfigurationError("Operation not available")

    @classmethod
    def loadYAML(cls, resource):
        try:
            config = yaml.load(resource)
            return cls(config)
        except yaml.YAMLError as e:
            raise ConfigurationError("Error loading YAML resource:", e)

    @classmethod
    def loadJSON(cls, resource):
        raise ConfigurationError("Operation not available")

    @classmethod
    def loadXML(cls, resource):
        raise ConfigurationError("Operation not available")
