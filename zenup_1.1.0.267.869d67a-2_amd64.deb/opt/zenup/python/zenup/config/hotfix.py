##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################

from zenup.config import intvalue, require
from zenup.config.zup import ZupConfiguration

class HotfixConfiguration(ZupConfiguration):
    """
    Configuration loaded from a hotfix config YAML
    """

    TYPE = "hotfix"

    def __init__(self, resource):
        super(HotfixConfiguration, self).__init__(resource)

    @intvalue(name="rps", minval=0)
    def _rps(self):
        return self.config.get("rps")

    @require(emptyOK=False, name="customer")
    def _customer(self):
        return self.config.get("customer")
