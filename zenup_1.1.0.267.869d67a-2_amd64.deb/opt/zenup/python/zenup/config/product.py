##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################

import time
from datetime import datetime

from zenup.config import Configuration, default, require, path, intvalue

class ProductConfiguration(Configuration):
    """
    Configuration for a registered ZenUp Product.
    """

    def __init__(self, config):
        super(ProductConfiguration, self).__init__(config)

    @path(name="path", dir=True, rOK=True, wOK=True, xOK=True)
    def _path(self):
        return self.config.get("path")

    @path(name="home", dir=True)
    def _home(self):
        return self.config.get("home")

    @require(name="id", emptyOK=False)
    def _id_(self):
        return self.config.get("id_")

    @default("")
    def _name(self):
        return self.config.get("name")

    @default("")
    def _zupfile(self):
        return self.config.get("zupfile")

    @intvalue(minval=0, name="revision")
    @default(0)
    def _revision(self):
        return self.config.get("revision")

    @default("")
    def _hotfix(self):
        return self.config.get("hotfix")

    @intvalue(minval=0, name="created")
    @default(0)
    def _created(self):
        created = self.config.get("created")
        try: 
            return time.mktime(datetime.strptime(created,"%c").timetuple())
        except Exception:
            pass
        return created
        
    @intvalue(minval=0, name="lastupdate")
    @default(0)
    def _lastupdate(self):
        lastupdate = self.config.get("lastupdate")
        try:
            return time.mktime(datetime.strptime(lastupdate,"%c").timetuple())
        except Exception:
            pass
        return lastupdate

    @default(None)
    def _upgrading(self):
        return self.config.get("upgrading")
