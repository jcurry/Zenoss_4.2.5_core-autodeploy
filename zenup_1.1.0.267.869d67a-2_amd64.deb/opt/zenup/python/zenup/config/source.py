##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################

import re

from zenup.config import Configuration
from zenup.config import require, listify


def is_valid_product(value):
    WHITELIST = re.compile(r"^[\w\-\.]+$")
    BLACKLIST = ('.', '..', 'status.yaml', 'log')
    return WHITELIST.match(value) and value not in BLACKLIST


class SourceConfiguration(Configuration):
    """
    Configuration loaded from a pristine source YAML
    """
    
    TYPE = "product"

    def __init__(self, resource):
        super(SourceConfiguration, self).__init__(resource)

    @require(criteria=is_valid_product, name="product")
    def _product(self):
        return self.config.get("product")

    @listify()
    def _directoryWhitelist(self):
        return self.config.get("local_diff_directory_whitelist")

    @listify()
    def _directoryBlacklist(self):
        return self.config.get("local_diff_directory_blacklist")

    @listify()
    def _fileWhitelist(self):
        return self.config.get("local_diff_file_pattern_whitelist")

    @listify()
    def _fileBlacklist(self):
        return self.config.get("local_diff_file_pattern_blacklist")
