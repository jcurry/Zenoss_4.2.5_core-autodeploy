##############################################################################
#
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
#
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
#
##############################################################################

import unittest
from mockito import when

from zenup.config import Configuration, ConfigurationError
from zenup.config import require, equal, default, intvalue, listify, \
                         cast, path

class TestValidator(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_cast(self):
        
        # Cast a number into a string
        @cast(str)
        def get_value():
            return 100

        self.assertEqual(get_value(), "100")

    def test_listify(self):

        @listify()
        def get_value(value):
            return value

        # 1. Listify a NoneType
        self.assertEqual(get_value(None), [])

        # 2. Listify an empty string
        self.assertEqual(get_value(""), [])

        # 3. Listify an empty list
        self.assertEqual(get_value([]), [])

        # 4. Listify a list
        listData = ["data", 5, {"hello":"world"}]
        self.assertEqual(get_value(listData), listData)

        # 5. Listify an iterable
        self.assertEqual(get_value(iter(listData)), listData)
        self.assertEqual(get_value(tuple(listData)), listData)

        # 6. Listify a dict
        self.assertEqual(get_value({}), [{}])
        self.assertEqual(get_value({"hello":"world"}), [{"hello":"world"}])

        # 7. Listify a non-iterable
        self.assertEqual(get_value(0), [0])
        self.assertEqual(get_value(False), [False])
        self.assertEqual(get_value("data"), ["data"])

    def test_path(self):
        import os

        @path()
        def get_value(value):
            return value

        @path(dir=True)
        def get_value_dir(value):
            return value

        @path(file=False)
        def get_value_file(value):
            return value

        @path(rOK=True)
        def get_value_rOK(value):
            return value

        @path(wOK=False)
        def get_value_wOK(value):
            return value

        @path(xOK=True)
        def get_value_xOK(value):
            return value

        # 1. NoneType value/ Does not exist
        self.assertRaises(ConfigurationError, get_value, None)

        p = "/path/not/exist"
        when(os.path).exists(p).thenReturn(False)
        self.assertRaises(ConfigurationError, get_value, p)

        p = "/path/exists"
        when(os.path).exists(p).thenReturn(True)
        self.assertEqual(get_value(p), p)

        # 2. Directory check
        p = "/path/is/dir"
        when(os.path).exists(p).thenReturn(True)
        when(os.path).isdir(p).thenReturn(True)
        self.assertEqual(get_value_dir(p), p)

        p = "/path/is/not/dir"
        when(os.path).exists(p).thenReturn(True)
        when(os.path).isdir(p).thenReturn(False)
        self.assertRaises(ConfigurationError, get_value_dir, p)

        # 3. File check
        p = "/path/is/file"
        when(os.path).exists(p).thenReturn(True)
        when(os.path).isfile(p).thenReturn(True)
        self.assertRaises(ConfigurationError, get_value_file, p)

        p = "/path/is/not/file"
        when(os.path).exists(p).thenReturn(True)
        when(os.path).isfile(p).thenReturn(False)
        self.assertEqual(get_value_file(p), p)

        # 4. Readable check
        p = "/path/is/readable"
        when(os.path).exists(p).thenReturn(True)
        when(os).access(p, os.R_OK).thenReturn(True)
        self.assertEqual(get_value_rOK(p), p)

        p = "/path/is/not/readable"
        when(os.path).exists(p).thenReturn(True)
        when(os).access(p, os.R_OK).thenReturn(False)
        self.assertRaises(ConfigurationError, get_value_rOK, p)

        # 5. Writeable check
        p = "/path/is/writeable"
        when(os.path).exists(p).thenReturn(True)
        when(os).access(p, os.W_OK).thenReturn(True)
        self.assertRaises(ConfigurationError, get_value_wOK, p)

        p = "/path/is/not/writeable"
        when(os.path).exists(p).thenReturn(True)
        when(os).access(p, os.W_OK).thenReturn(False)
        self.assertEqual(get_value_wOK(p), p)

        # 6. Executable check
        p = "/path/is/executable"
        when(os.path).exists(p).thenReturn(True)
        when(os).access(p, os.X_OK).thenReturn(True)
        self.assertEqual(get_value_xOK(p), p)

        p = "/path/is/not/executable"
        when(os.path).exists(p).thenReturn(True)
        when(os).access(p, os.X_OK).thenReturn(False)
        self.assertRaises(ConfigurationError, get_value_xOK, p)

    def test_intvalue(self):

        @intvalue(minval=0, maxval=100)
        def get_value_bounds(value):
            return value

        @intvalue(minval=0)
        def get_value_lower(value):
            return value

        @intvalue(maxval=100)
        def get_value_upper(value):
            return value

        @intvalue()
        def get_value(value):
            return value

        # 1. Convert from int
        self.assertEqual(get_value_bounds(10), 10)
        self.assertRaises(ConfigurationError, get_value_bounds, -1)
        self.assertRaises(ConfigurationError, get_value_bounds, 101)
        self.assertEqual(get_value_lower(10), 10)
        self.assertRaises(ConfigurationError, get_value_lower, -1)
        self.assertEqual(get_value_upper(10), 10)
        self.assertRaises(ConfigurationError, get_value_upper, 101)
        self.assertEqual(get_value(10), 10)

        # 2. Convert from string
        self.assertEqual(get_value("10"), 10)
        self.assertRaises(ConfigurationError, get_value, "not-a-number")
        self.assertRaises(ConfigurationError, get_value, "10.9")

        # 3. Convert from float
        self.assertEqual(get_value(10.9), 10)

        # 4. Convert from non-integer type
        self.assertRaises(ConfigurationError, get_value, None)

    def test_default(self):
    
        @default(10)
        def get_value(value):
            return value

        # 1. NoneType
        self.assertEqual(get_value(None), 10)

        # 2. Empty value
        self.assertEqual(get_value(""), "")
        self.assertEqual(get_value([]), [])
        self.assertEqual(get_value(0), 0)
        self.assertEqual(get_value(False), False)

        # 3. Non-empty value
        self.assertEqual(get_value("test"), "test")
        self.assertEqual(get_value([100]), [100])
        self.assertEqual(get_value(100), 100)
        self.assertEqual(get_value(True), True)

    def test_equal(self):

        @equal("test")
        def get_value(value):
            return value

        self.assertEqual(get_value("test"), "test")
        self.assertRaises(ConfigurationError, get_value, "hat")
        self.assertRaises(ConfigurationError, get_value, ["test"])

    def test_require(self):        

        # 1. Empty OK and no criteria
        @require()
        def get_value(value):
            return value

        self.assertEqual(get_value("test"), "test")
        self.assertEqual(get_value(""), "")
        self.assertEqual(get_value([]), [])
        self.assertEqual(get_value(0), 0)
        self.assertEqual(get_value(False), False)
        self.assertRaises(ConfigurationError, get_value, None)

        # 2. Empty NOT OK and no criteria
        @require(emptyOK=False)
        def get_value_not_empty(value):
            return value

        self.assertEqual(get_value_not_empty("test"), "test")
        self.assertRaises(ConfigurationError, get_value_not_empty, "")
        self.assertRaises(ConfigurationError, get_value_not_empty, [])
        self.assertRaises(ConfigurationError, get_value_not_empty, 0)
        self.assertRaises(ConfigurationError, get_value_not_empty, False)
        self.assertRaises(ConfigurationError, get_value_not_empty, None)

        # 3. Empty OK and criteria
        @require(criteria=lambda x: x < 10)
        def get_value_criteria(value):
            return value

        self.assertEqual(get_value_criteria(1), 1)
        self.assertEqual(get_value_criteria(0), 0)
        self.assertRaises(ConfigurationError, get_value_criteria, 11)
        self.assertRaises(ConfigurationError, get_value_criteria, None)

        # 4. Empty NOT OK and criteria
        @require(criteria=lambda x: x < 10, emptyOK=False)
        def get_value_not_empty_and_criteria(value):
            return value

        self.assertEqual(get_value_not_empty_and_criteria(1), 1)
        self.assertRaises(ConfigurationError, get_value_not_empty_and_criteria, 0)
        self.assertRaises(ConfigurationError, get_value_not_empty_and_criteria, 11)
        self.assertRaises(ConfigurationError, get_value_not_empty_and_criteria, None)


class TestConfiguration(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_load(self):

        import yaml

        when(yaml).load("badresource").thenRaise(yaml.YAMLError())
        self.assertRaises(ConfigurationError, Configuration.load, "badresource")

        when(yaml).load("badconfig").thenReturn("badconfig")
        self.assertRaises(ConfigurationError, Configuration.load, "badconfig")
        self.assertRaises(ConfigurationError, Configuration, "badconfig")

    def test_type_attribute(self):

        import yaml

        config1 = {"type": "badtype"}
        when(yaml).load("config1").thenReturn(config1)
        self.assertRaises(ConfigurationError, Configuration.load, "config1")
        self.assertRaises(ConfigurationError, Configuration, config1)

        config2 = {}
        when(yaml).load("config2").thenReturn(config2)
        c = Configuration.load("config2")
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)

        c = Configuration(config2)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)

    def test_version_attribute(self):

        import yaml

        config3 = {"version": 10}
        when(yaml).load("config3").thenReturn(config3)
        c = Configuration.load("config3")
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 10)

        c = Configuration(config3)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 10)
