##############################################################################
#
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
#
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
#
##############################################################################

import unittest
from mockito import when

from zenup.config import ConfigurationError
from zenup.config.hotfix import HotfixConfiguration as HConfig

class TestHotfixConfiguration(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_rps_attribute(self):
        config = { "type":     HConfig.TYPE,
                   "product":  "testproduct",
                   "created":  "today!",
                   "revision": "10",
                   "customer": "testcustomer",
                   "check":     [],
                   "pre":       [],
                   "post":      []}

        import yaml
        when(yaml).load(config).thenReturn(config)

        config["rps"] = "100"
        c = HConfig(config)
        self.assertEqual(c.type, HConfig.TYPE)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])
        self.assertEqual(c.revision, int(config["revision"]))
        self.assertEqual(c.created, config["created"])
        self.assertEqual(c.rps, int(config["rps"]))
        self.assertEqual(c.customer, config["customer"])

        config["rps"] = -100
        self.assertRaises(ConfigurationError, HConfig, config)

        config["rps"] = None
        self.assertRaises(ConfigurationError, HConfig, config)

        config["rps"] = "sometext"
        self.assertRaises(ConfigurationError, HConfig, config)

    def test_customer_attribute(self):
        config = {"type":      HConfig.TYPE,
                  "product":   "testproduct",
                  "created":   "yesterday",
                  "revision":  "20",
                  "rps":       "30",
                  "check":     [],
                  "pre":       [],
                  "post":      []}

        import yaml
        when(yaml).load(config).thenReturn(config)

        config["customer"] = "somecustomer"
        c = HConfig(config)
        self.assertEqual(c.type, HConfig.TYPE)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])
        self.assertEqual(c.revision, int(config["revision"]))
        self.assertEqual(c.created, config["created"])
        self.assertEqual(c.rps, int(config["rps"]))
        self.assertEqual(c.customer, config["customer"])

        config["customer"] = ""
        self.assertRaises(ConfigurationError, HConfig, config)

        del config["customer"]
        self.assertRaises(ConfigurationError, HConfig, config)
        pass
