##############################################################################
#
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
#
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
#
##############################################################################

import os

import unittest
from mockito import when, unstub

from zenup.config import ConfigurationError
from zenup.config.product import ProductConfiguration as PConfig

class TestProductConfiguration(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        unstub()

    def test_path_attribute(self):
        config = {"home":"/path/to/home", "id_":"productid"}
        when(os.path).exists(config["home"]).thenReturn(True)
        when(os.path).isdir(config["home"]).thenReturn(True)

        # path is NoneType
        self.assertRaises(ConfigurationError, PConfig, config)

        # path is empty string
        config["path"] = ""
        self.assertRaises(ConfigurationError, PConfig, config)

        # path not exist
        config["path"] = "/path/not/exist"
        when(os.path).exists(config["path"]).thenReturn(False)
        self.assertRaises(ConfigurationError, PConfig, config)
            
        # path not a dir
        config["path"] = "/path/not/dir"
        when(os.path).exists(config["path"]).thenReturn(True)
        when(os.path).isdir(config["path"]).thenReturn(False)
        when(os).access(config["path"], os.R_OK).thenReturn(True)
        when(os).access(config["path"], os.W_OK).thenReturn(True)
        when(os).access(config["path"], os.X_OK).thenReturn(True)

        # path not readable
        config["path"] = "/path/not/readable"
        when(os.path).exists(config["path"]).thenReturn(True)
        when(os.path).isdir(config["path"]).thenReturn(True)
        when(os).access(config["path"], os.R_OK).thenReturn(False)
        when(os).access(config["path"], os.W_OK).thenReturn(True)
        when(os).access(config["path"], os.X_OK).thenReturn(True)

        # path not writeable
        config["path"] = "/path/not/writeable"
        when(os.path).exists(config["path"]).thenReturn(True)
        when(os.path).isdir(config["path"]).thenReturn(True)
        when(os).access(config["path"], os.R_OK).thenReturn(True)
        when(os).access(config["path"], os.W_OK).thenReturn(False)
        when(os).access(config["path"], os.X_OK).thenReturn(True)

        # path not executable
        config["path"] = "/path/not/executable"
        when(os.path).exists(config["path"]).thenReturn(True)
        when(os.path).isdir(config["path"]).thenReturn(True)
        when(os).access(config["path"], os.R_OK).thenReturn(True)
        when(os).access(config["path"], os.W_OK).thenReturn(True)
        when(os).access(config["path"], os.X_OK).thenReturn(False)

        # success
        config["path"] = "/path/to/success"
        when(os.path).exists(config["path"]).thenReturn(True)
        when(os.path).isdir(config["path"]).thenReturn(True)
        when(os).access(config["path"], os.R_OK).thenReturn(True)
        when(os).access(config["path"], os.W_OK).thenReturn(True)
        when(os).access(config["path"], os.X_OK).thenReturn(True)

        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, "")
        self.assertEqual(c.zupfile, "")
        self.assertEqual(c.revision, 0)
        self.assertEqual(c.created, 0)
        self.assertEqual(c.lastupdate, 0)         

    def test_home_attribute(self):
        config = {"path":"/path/to/product", "id_":"test"}
        when(os.path).exists(config["path"]).thenReturn(True)
        when(os.path).isdir(config["path"]).thenReturn(True)
        when(os).access(config["path"], os.R_OK).thenReturn(True)
        when(os).access(config["path"], os.W_OK).thenReturn(True)
        when(os).access(config["path"], os.X_OK).thenReturn(True)

        # home is NoneType
        self.assertRaises(ConfigurationError, PConfig, config)

        # home is empty string
        config["home"] = ""
        self.assertRaises(ConfigurationError, PConfig, config)

        # home does not exist
        config["home"] = "/path/not/exist"
        when(os.path).exists(config["home"]).thenReturn(False)
        self.assertRaises(ConfigurationError, PConfig, config)

        # home is not a directory
        config["home"] = "/path/not/dir"
        when(os.path).exists(config["home"]).thenReturn(True)
        when(os.path).isdir(config["home"]).thenReturn(False)
        self.assertRaises(ConfigurationError, PConfig, config)

        # success
        config["home"] = "/path/to/success"
        when(os.path).exists(config["home"]).thenReturn(True)
        when(os.path).isdir(config["home"]).thenReturn(True)
        
        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, "")
        self.assertEqual(c.zupfile, "")
        self.assertEqual(c.revision, 0)
        self.assertEqual(c.created, 0)
        self.assertEqual(c.lastupdate, 0)         

    def test_id_attribute(self):
        config = {"path":"/path/to/product", "home":"/path/to/home"}
        when(os.path).exists(config["path"]).thenReturn(True)
        when(os.path).isdir(config["path"]).thenReturn(True)
        when(os).access(config["path"], os.R_OK).thenReturn(True)
        when(os).access(config["path"], os.W_OK).thenReturn(True)
        when(os).access(config["path"], os.X_OK).thenReturn(True)
        when(os.path).exists(config["home"]).thenReturn(True)
        when(os.path).isdir(config["home"]).thenReturn(True)

        # id is NoneType
        self.assertRaises(ConfigurationError, PConfig, config)

        # id is Empty String
        config["id_"] = ""
        self.assertRaises(ConfigurationError, PConfig, config)

        # id success
        config["id_"] = "test"
        
        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, "")
        self.assertEqual(c.zupfile, "")
        self.assertEqual(c.revision, 0)
        self.assertEqual(c.created, 0)
        self.assertEqual(c.lastupdate, 0)         

    def test_name_attribute(self):
        config = {"path":"/path/to/product", "home":"/path/to/home", "id_":"test"}
        when(os.path).exists(config["path"]).thenReturn(True)
        when(os.path).isdir(config["path"]).thenReturn(True)
        when(os).access(config["path"], os.R_OK).thenReturn(True)
        when(os).access(config["path"], os.W_OK).thenReturn(True)
        when(os).access(config["path"], os.X_OK).thenReturn(True)
        when(os.path).exists(config["home"]).thenReturn(True)
        when(os.path).isdir(config["home"]).thenReturn(True)

        # name is NoneType
        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, "")
        self.assertEqual(c.zupfile, "")
        self.assertEqual(c.revision, 0)
        self.assertEqual(c.created, 0)
        self.assertEqual(c.lastupdate, 0)         
                
        # name is not NoneType
        config["name"] = "test name"

        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, config["name"])
        self.assertEqual(c.zupfile, "")
        self.assertEqual(c.revision, 0)
        self.assertEqual(c.created, 0)
        self.assertEqual(c.lastupdate, 0)         

    def test_zupfile_attribute(self):
        config = {"path":"/path/to/product", "home":"/path/to/home", "id_":"test"}
        when(os.path).exists(config["path"]).thenReturn(True)
        when(os.path).isdir(config["path"]).thenReturn(True)
        when(os).access(config["path"], os.R_OK).thenReturn(True)
        when(os).access(config["path"], os.W_OK).thenReturn(True)
        when(os).access(config["path"], os.X_OK).thenReturn(True)
        when(os.path).exists(config["home"]).thenReturn(True)
        when(os.path).isdir(config["home"]).thenReturn(True)

        # zupfile is NoneType
        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, "")
        self.assertEqual(c.zupfile, "")
        self.assertEqual(c.revision, 0)
        self.assertEqual(c.created, 0)
        self.assertEqual(c.lastupdate, 0)         
                
        # zupfile is not NoneType
        config["zupfile"] = "test name"

        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, "")
        self.assertEqual(c.zupfile, config["zupfile"])
        self.assertEqual(c.revision, 0)
        self.assertEqual(c.created, 0)
        self.assertEqual(c.lastupdate, 0)         

    def test_revision_attribute(self):
        config = {"path":"/path/to/product", "home":"/path/to/home", "id_":"test"}
        when(os.path).exists(config["path"]).thenReturn(True)
        when(os.path).isdir(config["path"]).thenReturn(True)
        when(os).access(config["path"], os.R_OK).thenReturn(True)
        when(os).access(config["path"], os.W_OK).thenReturn(True)
        when(os).access(config["path"], os.X_OK).thenReturn(True)
        when(os.path).exists(config["home"]).thenReturn(True)
        when(os.path).isdir(config["home"]).thenReturn(True)

        # revision is NoneType
        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, "")
        self.assertEqual(c.zupfile, "")
        self.assertEqual(c.revision, 0)
        self.assertEqual(c.created, 0)
        self.assertEqual(c.lastupdate, 0)         

        # revision is not a number
        config["revision"] = "NaN"
        self.assertRaises(ConfigurationError, PConfig, config)

        # revision is a number (string)
        config["revision"] = "425"
        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, "")
        self.assertEqual(c.zupfile, "")
        self.assertEqual(c.revision, int(config["revision"]))
        self.assertEqual(c.created, 0)
        self.assertEqual(c.lastupdate, 0)         

    def test_created_attribute(self):
        config = {"path":"/path/to/product", "home":"/path/to/home", "id_":"test"}
        when(os.path).exists(config["path"]).thenReturn(True)
        when(os.path).isdir(config["path"]).thenReturn(True)
        when(os).access(config["path"], os.R_OK).thenReturn(True)
        when(os).access(config["path"], os.W_OK).thenReturn(True)
        when(os).access(config["path"], os.X_OK).thenReturn(True)
        when(os.path).exists(config["home"]).thenReturn(True)
        when(os.path).isdir(config["home"]).thenReturn(True)

        # created is a NoneType
        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, "")
        self.assertEqual(c.zupfile, "")
        self.assertEqual(c.revision, 0)
        self.assertEqual(c.created, 0)
        self.assertEqual(c.lastupdate, 0)         

        # created is not a NoneType
        config["created"] = 12345
        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, "")
        self.assertEqual(c.zupfile, "")
        self.assertEqual(c.revision, 0)
        self.assertEqual(c.created, config["created"])
        self.assertEqual(c.lastupdate, 0)         

    def test_lastupdate_attribute(self):
        config = {"path":"/path/to/product", "home":"/path/to/home", "id_":"test"}
        when(os.path).exists(config["path"]).thenReturn(True)
        when(os.path).isdir(config["path"]).thenReturn(True)
        when(os).access(config["path"], os.R_OK).thenReturn(True)
        when(os).access(config["path"], os.W_OK).thenReturn(True)
        when(os).access(config["path"], os.X_OK).thenReturn(True)
        when(os.path).exists(config["home"]).thenReturn(True)
        when(os.path).isdir(config["home"]).thenReturn(True)

        # lastupdate is a NoneType
        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, "")
        self.assertEqual(c.zupfile, "")
        self.assertEqual(c.revision, 0)
        self.assertEqual(c.created, 0)
        self.assertEqual(c.lastupdate, 0)         

        # lastupdate is not a NoneType
        config["lastupdate"] = 12345
        c = PConfig(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.path, config["path"])
        self.assertEqual(c.home, config["home"])
        self.assertEqual(c.id_, config["id_"])
        self.assertEqual(c.name, "")
        self.assertEqual(c.zupfile, "")
        self.assertEqual(c.revision, 0)
        self.assertEqual(c.created, 0)
        self.assertEqual(c.lastupdate, config["lastupdate"])
