##############################################################################
#
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
#
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
#
##############################################################################

import unittest
from mockito import when

from zenup.config import ConfigurationError
from zenup.config.source import SourceConfiguration as SourceConfig

class TestSourceConfiguration(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_product_attribute(self):
        import yaml

        config = {"type":SourceConfig.TYPE, "product":"testproduct"}
        when(yaml).load(config).thenReturn(config)

        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])

        config["product"] = None
        self.assertRaises(ConfigurationError, SourceConfig, config)
        
        config["product"] = ".."
        self.assertRaises(ConfigurationError, SourceConfig, config)

        config["product"] = "?*()("
        self.assertRaises(ConfigurationError, SourceConfig, config)
        
    def test_directoryWhitelist_attribute(self):
        import yaml

        key = "local_diff_directory_whitelist"

        config = {"type": SourceConfig.TYPE, "product":"test", key:""}
        when(yaml).load(config).thenReturn(config)

        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])

        config[key] = "somevalue"
        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [config[key]])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])

        config[key] = ["list","of","values"]
        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, config[key])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])

    def test_directoryBlacklist_attribute(self):
        import yaml

        key = "local_diff_directory_blacklist"

        config = {"type": SourceConfig.TYPE, "product":"test", key:""}
        when(yaml).load(config).thenReturn(config)

        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])

        config[key] = "somevalue"
        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [config[key]])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])

        config[key] = ["list","of","values"]
        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, config[key])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])

    def test_fileWhitelist_attribute(self):
        import yaml

        key = "local_diff_file_pattern_whitelist"

        config = {"type": SourceConfig.TYPE, "product":"test", key:""}
        when(yaml).load(config).thenReturn(config)

        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])

        config[key] = "somevalue"
        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [config[key]])
        self.assertEqual(c.fileBlacklist, [])

        config[key] = ["list","of","values"]
        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, config[key])
        self.assertEqual(c.fileBlacklist, [])

    def test_fileBlacklist_attribute(self):
        import yaml

        key = "local_diff_file_pattern_blacklist"

        config = {"type": SourceConfig.TYPE, "product":"test", key:""}
        when(yaml).load(config).thenReturn(config)

        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])

        config[key] = "somevalue"
        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [config[key]])

        config[key] = ["list","of","values"]
        c = SourceConfig(config)
        self.assertEqual(c.type, SourceConfig.TYPE)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, config[key])
