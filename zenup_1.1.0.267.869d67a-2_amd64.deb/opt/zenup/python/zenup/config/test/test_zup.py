##############################################################################
#
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
#
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
#
##############################################################################

import unittest
from mockito import when
from copy import deepcopy

from zenup.config import ConfigurationError
from zenup.config.zup import ZupConfiguration as ZConfig, \
                             Manifest, ManifestFix, ManifestChange, ZupLifecyclePhase
                       

class TestZupConfiguration(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_revision_attribute(self):
        config = {"type":ZConfig.TYPE, 
                  "product":"testproduct",
                  "created":"today!",
                  "check":     [],
                  "pre":       [],
                  "post":      []}

        import yaml
        when(yaml).load(config).thenReturn(config)

        config["revision"] = "100"
        c = ZConfig(config)
        self.assertEqual(c.type, ZConfig.TYPE)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])
        self.assertEqual(c.revision, int(config["revision"]))
        self.assertEqual(c.created, config["created"])

        config["revision"] = -100
        self.assertRaises(ConfigurationError, ZConfig, config)

        config["revision"] = None
        self.assertRaises(ConfigurationError, ZConfig, config)

        config["revision"] = "sometext"
        self.assertRaises(ConfigurationError, ZConfig, config)

    def test_minimum_attribute(self):
        config = {"type":ZConfig.TYPE, "product":"test", "created":"date", 
                  "revision":100,
                  "check":     [],
                  "pre":       [],
                  "post":      []}
        import yaml
        when(yaml).load(config).thenReturn(config)

        # NoneType
        c = ZConfig(config)
        self.assertEqual(c.type, ZConfig.TYPE)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])
        self.assertEqual(c.revision, int(config["revision"]))
        self.assertEqual(c.minimum, c.revision)
        self.assertEqual(c.created, config["created"])

        # Not a number
        config["minimum"] = "NaN"
        self.assertRaises(ConfigurationError, ZConfig, config)

        # Number (string)
        config["minimum"] = "10"
        c = ZConfig(config)
        self.assertEqual(c.type, ZConfig.TYPE)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])
        self.assertEqual(c.revision, int(config["revision"]))
        self.assertEqual(c.minimum, int(config["minimum"]))
        self.assertEqual(c.created, config["created"])

    def test_created_attribute(self):
        config = {"type":ZConfig.TYPE,
                  "product": "testproduct",
                  "revision": 256,
                  "check":     [],
                  "pre":       [],
                  "post":      []}

        import yaml
        when(yaml).load(config).thenReturn(config)

        config["created"] = "datestring"
        c = ZConfig(config)
        self.assertEqual(c.type, ZConfig.TYPE)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])
        self.assertEqual(c.revision, config["revision"])
        self.assertEqual(c.created, config["created"])

        config["created"] = ""
        c = ZConfig(config)
        self.assertEqual(c.type, ZConfig.TYPE)
        self.assertEqual(c.product, config["product"])
        self.assertEqual(c.directoryWhitelist, [])
        self.assertEqual(c.directoryBlacklist, [])
        self.assertEqual(c.fileWhitelist, [])
        self.assertEqual(c.fileBlacklist, [])
        self.assertEqual(c.revision, config["revision"])
        self.assertEqual(c.created, config["created"])

        del config["created"]
        self.assertRaises(ConfigurationError, ZConfig, config)

    def test_lifecycle_scripts(self):

        import yaml
        config = {"type":ZConfig.TYPE,
                  "created": "today",
                  "revision": 69,
                  "product": "testproduct",
                  "check": ["check/check1"],
                  "pre": [],
                  "post": ["post/post1", "post/post2"]}

        when(yaml).load(config).thenReturn(config)
        c = ZConfig(config)

        self.assertEqual(c.pre, ZupLifecyclePhase.makePhase(("pre", config["pre"])))
        self.assertEqual(c.check, ZupLifecyclePhase.makePhase(("check", config["check"])))
        self.assertEqual(c.post, ZupLifecyclePhase.makePhase(("post", config["post"])))

        # Now test the updated config format where args can get passed in (and descriptions)
        config["check"] = ['check/check', 'check/fileThatsNotThere']
        config["pre"] = [{'pre/pre1': ['arg1', 'arg2', {'description': 'Here is my description of this pre script'}]},
                         {'pre/pre2': [{'description': 'Here is another description'}]}]
        config["post"] = [{'post/post1': ['Arg1', 'Arg2', {'description': None}]}, {'post/post2': [{'description': 'Yet another description!'}]}]
        c = ZConfig(config)
        self.assertEqual(c.pre, ZupLifecyclePhase.makePhase(("pre", config["pre"])))
        self.assertEqual(c.check, ZupLifecyclePhase.makePhase(("check", config["check"])))
        self.assertEqual(c.post, ZupLifecyclePhase.makePhase(("post", config["post"])))


class TestManifest(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_fixes_attribute(self):
        config = {}
        import yaml
        when(yaml).load(config).thenReturn(config)

        config["fixes"] = [{"id":"TEST-1234"}]
        c = Manifest(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.patches, [])
        self.assertEqual(c.changes, {})
        
        self.assertEqual(len(c.fixes), len(config["fixes"]))
        self.assertEqual(c.fixes[0].id, config["fixes"][0]["id"])
        self.assertEqual(c.fixes[0].description, "")
        self.assertEqual(c.fixes[0].patches, [])

        config["fixes"] = []
        self.assertRaises(ConfigurationError, Manifest, config)

        del config["fixes"]
        self.assertRaises(ConfigurationError, Manifest, config)

    def test_patches_attribute(self):
        config = {"fixes": [{"id":"TEST-1234"}]}
        import yaml
        when(yaml).load(config).thenReturn(config)

        config["patches"] = "patch"
        c = Manifest(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.patches, [config["patches"]])
        self.assertEqual(c.changes, {})
        self.assertEqual(len(c.fixes), len(config["fixes"]))
        self.assertEqual(c.fixes[0].id, config["fixes"][0]["id"])
        self.assertEqual(c.fixes[0].description, "")
        self.assertEqual(c.fixes[0].patches, [])

        config["patches"] = ["patch"]
        c = Manifest(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.patches, config["patches"])
        self.assertEqual(c.changes, {})
        self.assertEqual(len(c.fixes), len(config["fixes"]))
        self.assertEqual(c.fixes[0].id, config["fixes"][0]["id"])
        self.assertEqual(c.fixes[0].description, "")
        self.assertEqual(c.fixes[0].patches, [])

        config["patches"] = ("patch1", "patch2")
        c = Manifest(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.patches, list(config["patches"]))
        self.assertEqual(c.changes, {})
        self.assertEqual(len(c.fixes), len(config["fixes"]))
        self.assertEqual(c.fixes[0].id, config["fixes"][0]["id"])
        self.assertEqual(c.fixes[0].description, "")
        self.assertEqual(c.fixes[0].patches, [])

        config["patches"] = []
        c = Manifest(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.patches, [])
        self.assertEqual(c.changes, {})
        self.assertEqual(len(c.fixes), len(config["fixes"]))
        self.assertEqual(c.fixes[0].id, config["fixes"][0]["id"])
        self.assertEqual(c.fixes[0].description, "")
        self.assertEqual(c.fixes[0].patches, [])

        config["patches"] = ""
        c = Manifest(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.patches, [])
        self.assertEqual(c.changes, {})
        self.assertEqual(len(c.fixes), len(config["fixes"]))
        self.assertEqual(c.fixes[0].id, config["fixes"][0]["id"])
        self.assertEqual(c.fixes[0].description, "")
        self.assertEqual(c.fixes[0].patches, [])

        del config["patches"]
        c = Manifest(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.patches, [])
        self.assertEqual(c.changes, {})
        self.assertEqual(len(c.fixes), len(config["fixes"]))
        self.assertEqual(c.fixes[0].id, config["fixes"][0]["id"])
        self.assertEqual(c.fixes[0].description, "")
        self.assertEqual(c.fixes[0].patches, [])

    def test_changes_attribute(self):
        config = {"fixes": [{"id":"TEST-1234"}]}
        import yaml
        when(yaml).load(config).thenReturn(config)

        config["changes"] = {"patch":{}}
        c = Manifest(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.patches, [])

        self.assertEqual(len(c.changes), len(config["changes"]))
        self.assertEqual(c.changes["patch"].adds, [])
        self.assertEqual(c.changes["patch"].deletes, [])
        self.assertEqual(c.changes["patch"].modifies, [])

        self.assertEqual(len(c.fixes), len(config["fixes"]))
        self.assertEqual(c.fixes[0].id, config["fixes"][0]["id"])
        self.assertEqual(c.fixes[0].description, "")
        self.assertEqual(c.fixes[0].patches, [])


class TestManifestFix(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_id_attribute(self):
        config = {"description":"some description text",
                  "patches": ["patch1", "patch2"]}

        config["id"] = "TEST-1234"
        c = ManifestFix(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.id, config["id"])
        self.assertEqual(c.description, config["description"])
        self.assertListEqual(c.patches, config["patches"])

        config["id"] = ""
        self.assertRaises(ConfigurationError, ManifestFix, config)

        del config["id"]
        self.assertRaises(ConfigurationError, ManifestFix, config)
 
    def test_description_attribute(self):
        config = {"id":"TEST-1234"}

        config["description"] = "some description"
        c = ManifestFix(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.id, config["id"])
        self.assertEqual(c.description, config["description"])
        self.assertEqual(c.patches, [])

        config["description"] = ""
        c = ManifestFix(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.id, config["id"])
        self.assertEqual(c.description, "")
        self.assertEqual(c.patches, [])

        del config["description"]
        c = ManifestFix(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.id, config["id"])
        self.assertEqual(c.description, "")
        self.assertEqual(c.patches, [])

    def test_patches_attribute(self):
        config = {"id":"TEST-1234"}

        config["patches"] = "patchfile"
        c = ManifestFix(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.id, config["id"])
        self.assertEqual(c.description, "")
        self.assertListEqual(c.patches, [config["patches"]])

        config["patches"] = ["patchfile"]
        c = ManifestFix(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.id, config["id"])
        self.assertEqual(c.description, "")
        self.assertListEqual(c.patches, config["patches"])

        config["patches"] = ("patchfile1", "patchfile2",)
        c = ManifestFix(config) 
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.id, config["id"])
        self.assertEqual(c.description, "")
        self.assertListEqual(c.patches, list(config["patches"]))

        config["patches"] = []
        c = ManifestFix(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.id, config["id"])
        self.assertEqual(c.description, "")
        self.assertEqual(c.patches, [])
        
        del config["patches"]
        c = ManifestFix(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertEqual(c.id, config["id"])
        self.assertEqual(c.description, "")
        self.assertEqual(c.patches, [])

    def test_convertToList(self):
        items = [
            {"id":"TEST-1234", "description":"some description", "patches":"patch"},
            {"id":"TEST-4567", "description":"", "patches":["p1","p2"]},
            {"id":"TEST-4653"}]
        results = ManifestFix.convertToList(items)

        self.assertEqual(len(results), len(items))
        for r in results:
            for i in items:
                if i["id"] == r.id:
                    self.assertEqual(r.type, None)
                    self.assertEqual(r.version, 0)
                    self.assertEqual(r.id, i["id"])
                    self.assertEqual(r.description, i.get("description", ""))

                    patches = i.get("patches") or []
                    if not hasattr(patches, "__iter__"):
                        patches = [patches]
                    else:
                        patches = list(patches)

                    self.assertListEqual(r.patches, patches)
                    items.remove(i)
                    break
            assert i["id"] == r.id


class TestManifestChange(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_adds_attribute(self):
        config = {"adds": "somevalue"}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [config["adds"]])
        self.assertListEqual(c.modifies, [])
        self.assertListEqual(c.deletes, [])
            
        config = {"adds": ["somevalue"]}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, config["adds"])
        self.assertListEqual(c.modifies, [])
        self.assertListEqual(c.deletes, [])

        config = {"adds": ("somevalue", "anothervalue",)}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, list(config["adds"]))
        self.assertListEqual(c.modifies, [])
        self.assertListEqual(c.deletes, [])

        config = {"adds": ""}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [])
        self.assertListEqual(c.modifies, [])
        self.assertListEqual(c.deletes, [])

        config = {"adds": []}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [])
        self.assertListEqual(c.modifies, [])
        self.assertListEqual(c.deletes, [])

    def test_modifies_attribute(self):
        config = {"modifies": "somevalue"}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [])
        self.assertListEqual(c.modifies, [config["modifies"]])
        self.assertListEqual(c.deletes, [])
            
        config = {"modifies": ["somevalue"]}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [])
        self.assertListEqual(c.modifies, config["modifies"])
        self.assertListEqual(c.deletes, [])

        config = {"modifies": ("somevalue", "anothervalue",)}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [])
        self.assertListEqual(c.modifies, list(config["modifies"]))
        self.assertListEqual(c.deletes, [])

        config = {"modifies": ""}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [])
        self.assertListEqual(c.modifies, [])
        self.assertListEqual(c.deletes, [])

        config = {"modifies": []}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [])
        self.assertListEqual(c.modifies, [])
        self.assertListEqual(c.deletes, [])

    def test_deletes_attribute(self):
        config = {"deletes": "somevalue"}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [])
        self.assertListEqual(c.modifies, [])
        self.assertListEqual(c.deletes, [config["deletes"]])
            
        config = {"deletes": ["somevalue"]}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [])
        self.assertListEqual(c.modifies, [])
        self.assertListEqual(c.deletes, config["deletes"])

        config = {"deletes": ("somevalue", "anothervalue",)}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [])
        self.assertListEqual(c.modifies, [])
        self.assertListEqual(c.deletes, list(config["deletes"]))

        config = {"deletes": ""}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [])
        self.assertListEqual(c.modifies, [])
        self.assertListEqual(c.deletes, [])

        config = {"deletes": []}
        c = ManifestChange(config)
        self.assertEqual(c.type, None)
        self.assertEqual(c.version, 0)
        self.assertListEqual(c.adds, [])
        self.assertListEqual(c.modifies, [])
        self.assertListEqual(c.deletes, [])

    def test_convertToDict(self):
        items = {
            "patch1": {"adds":"a1", "modifies":["m1","m2"], "deletes":[]},
            "patch2": {"adds":["a1","a2"], "modifies":["m1"], "deletes":"d1"},
            "patch3": {"adds":"", "modifies":"m1", "deletes":["d1","d2"]},
        }
        results = ManifestChange.convertToDict(items)

        self.assertEqual(len(results), len(items))
        for k,v in results.iteritems():
            assert k in items
            self.assertEqual(v.type, None)
            self.assertEqual(v.version, 0)

            adds = items[k].get("adds") or []
            if not hasattr(adds, "__iter__"):
                adds = [adds]
            else:
                adds = list(adds)
            self.assertListEqual(v.adds, adds)

            modifies = items[k].get("modifies") or []
            if not hasattr(modifies, "__iter__"):
                modifies = [modifies]
            else:
                modifies = list(modifies)
            self.assertListEqual(v.modifies, modifies)

            deletes = items[k].get("deletes") or []
            if not hasattr(deletes, "__iter__"):
                deletes = [deletes]
            else:
                deletes = list(deletes)
            self.assertListEqual(v.deletes, deletes)
