##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################
from zenup.config import cast, default, intvalue, require, listify
from zenup.config import Configuration, VALIDATOR_FLAG
from zenup.config.source import SourceConfiguration

import logging
logger = logging.getLogger("zenup")


class set_config_version(object):
    """
    Decorator that sets the config's version

    @returns void
    """

    def __init__(self):
        pass

    def __call__(self, f):
        def inner(*args, **kwargs):
            value = f(*args, **kwargs)
            parent_obj = f.__self__
            setattr(parent_obj, ZupConfiguration.CONFIG_VERSION_STRING, value)
        setattr(inner, VALIDATOR_FLAG, True)
        return inner

class config_version_dependent(object):
    """
    Validation decorator that decides if the attribute in question if
    part of the config based on the version.

    *** Implicitly makes the decorated config attr required ***
    TODO: Make this optionally required

    @param start_version: the first config version that this attribute
    is valid in (inclusive)
    @param end_version: the last config version that this attribtue is valid in
    @returns integer (inclusive)
    @raises ConfigurationError
    """

    def __init__(self, start=None, end=None):
        self.start = start
        self.end = end

    def __call__(self, f):
        def inner(*args, **kwargs):
            value = f(*args, **kwargs)
            parent_obj = args[0]
            # No default here, I want this to throw an AttribtueError if
            # if needed
            cfg_version = getattr(parent_obj,
                                  ZupConfiguration.CONFIG_VERSION_STRING)
            startbound = self.start is None or cfg_version >= self.start
            endbound = self.end is None or cfg_version <= self.end
            if not (startbound and endbound):
                parent_obj.valid = False
            return value
        setattr(inner, VALIDATOR_FLAG, True)
        return inner

class ZupLifecycleStep(object):

    def __init__(self, path, args, description):
        self.path = path
        self.args = args # List of args
        self.description = description

    def __str__(self):
        the_args = " ".join(self.args)
        the_str = self.path + " " + the_args if the_args else self.path
        return the_str

    def __eq__(self, other):
        if self.path == other.path and \
                        self.args == other.args and \
                        self.description == other.description:
            return True
        return False

class ZupLifecyclePhase(object):

    def __init__(self, name, steps):
        self.name = name
        self.steps = steps

    def __eq__(self, other):
        if self.name == other.name and self.steps == other.steps:
            return True
        return False

    @classmethod
    def makePhase(cls, (name, phase_yaml)):
        steps = []
        if phase_yaml is not None:
            for script_info in phase_yaml:
                description = ""
                script_args = []
                if isinstance(script_info, dict):
                    script, info = script_info.items()[0]
                    for piece in info:
                        if isinstance(piece, str):
                            script_args.append(piece)
                        elif isinstance(piece, dict) and "description" in piece:
                            description = piece["description"]
                else:
                    script = script_info
                step = ZupLifecycleStep(script, script_args, description)
                steps.append(step)

        logger.debug("Phase %s loaded: %s", name, [step.path for step in steps])
        return cls(name, steps)


class ZupConfiguration(SourceConfiguration):
    """
    Configuration loaded from a zup config YAML
    """
    
    TYPE = "archive"
    CONFIG_VERSION_STRING = 'CONFIG_VERSION'
    RESOURCE_CONFIG_VERSION_STRING = "config_version"

    def __init__(self, resource):
        self._valid = True
        # Calling this here because it needs to happen first
        self._set_config_version(resource)
        super(ZupConfiguration, self).__init__(resource)

    @property
    def valid(self):
        return self._valid

    @valid.setter
    def valid(self, value):
        self._valid = bool(value)

    def _set_config_version(self, resource):
        @intvalue()
        def getit():
            return resource.get(ZupConfiguration.RESOURCE_CONFIG_VERSION_STRING,
                                -1)

        setattr(self, ZupConfiguration.CONFIG_VERSION_STRING, getit())

    @intvalue(name="revision", minval=1)
    def _revision(self):
        return self.config.get("revision")

    # This is named revision because minimum is an optional argument that
    # defaults to revision when it is not found.
    @intvalue(name="revision", minval=0)
    def _minimum(self):
        minimum = self.config.get("minimum")
        return minimum if minimum is not None else self.config.get("revision")

    # Returns a ZupLifecyclePhase containing ZupLifecycleSteps
    @config_version_dependent(start=2)
    @cast(ZupLifecyclePhase.makePhase)
    def _check(self):
        return "check", self.config.get("check") if "check" in self.config \
            else None

    # Returns a ZupLifecyclePhase containing ZupLifecycleSteps
    @config_version_dependent(start=2)
    @cast(ZupLifecyclePhase.makePhase)
    def _pre(self):
        return "pre", self.config.get("pre") if "pre" in self.config else None

    # Returns a ZupLifecyclePhase containing ZupLifecycleSteps
    @config_version_dependent(start=2)
    @cast(ZupLifecyclePhase.makePhase)
    def _post(self):
        return "post", self.config.get("post") if "post" in self.config \
            else None

    @require(name="created")
    def _created(self):
        return self.config.get("created")

    @intvalue()
    def _config_version(self):
        return getattr(self, ZupConfiguration.CONFIG_VERSION_STRING)


class ManifestFix(Configuration):
    """
    Subtype of Manifest. Contains metadata of the contents of a zup
    """

    def __init__(self, config):
        super(ManifestFix, self).__init__(config)

    @require(name="id", emptyOK=False)
    def _id(self):
        return self.config.get("id")

    @default("")
    def _description(self):
        return self.config.get("description")

    @listify()
    def _patches(self):
        return self.config.get("patches")

    @classmethod
    def convertToList(cls, items):
        return [cls(i) for i in items]


class ManifestChange(Configuration):
    """
    Subtype of Manifest.  Contains files affected by a zup patch.
    """

    def __init__(self, config):
        super(ManifestChange, self).__init__(config)

    @listify()
    def _adds(self):
        return self.config.get("adds")

    @listify()
    def _modifies(self):
        return self.config.get("modifies")

    @listify()
    def _deletes(self):
        return self.config.get("deletes")

    @classmethod
    def convertToDict(cls, items):
        return {k:cls(v) for k,v in items.iteritems()}

    def changes(self):
        return {'modifies': self.modifies,
                'adds': self.adds,
                'deletes': self.deletes,}

class Manifest(Configuration):
    """
    Configuration loaded from a zup manifest YAML
    """
    
    def __init__(self, resource):
        super(Manifest, self).__init__(resource)

    @require(name="fixes", emptyOK=False)
    @cast(ManifestFix.convertToList)
    @listify()
    def _fixes(self):
        return self.config.get("fixes")

    @listify()
    def _patches(self):
        return self.config.get("patches")

    @cast(ManifestChange.convertToDict)
    @default({})
    def _changes(self):
        return self.config.get("changes")
