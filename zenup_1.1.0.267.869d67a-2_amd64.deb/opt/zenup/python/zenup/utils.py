##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################

import math
import os
import subprocess
import sys

PATCH_OK, PATCH_WARN, PATCH_ERROR = 0,1,2

def patch(fp, *options):
	cmd = ["patch", "--no-backup-if-mismatch"]
	if options:
		cmd.extend(options)

	p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stdin=fp, 
		stderr=subprocess.PIPE)
	stdout, stderr = p.communicate()

	return p.returncode, stdout, stderr

def fileopen(filename, access):
    return open(filename, access)

def progress(width, percent):
    marks = math.floor(width * (percent / 100.0))
    spaces = math.floor(width - marks)

    loader = "[%s%s]" % ("=" * int(marks), " " * int(spaces))

    sys.stdout.write("\t%s %d%%\r" % (loader, percent))
    if percent >= 100:
        sys.stdout.write("\n")

    sys.stdout.flush()
