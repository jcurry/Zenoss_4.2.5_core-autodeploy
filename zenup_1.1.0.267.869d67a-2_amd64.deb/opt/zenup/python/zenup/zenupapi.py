##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################

import os
import logging
import yaml
import tarfile
import tempfile
import stat
from zenup import ZenUpException
from zenup.zupproduct import ZupProduct
from zenup.archive import ArchiveError
from zenup.archive.source import PristineSource
from zenup.archive.zup import ZupArchive
from zenup.audit import getAuditLogHandler

logger = logging.getLogger("zenup")
auditLogger = logging.getLogger("audit")


class ZenUp(object):
    """
    API tool for performing operations on registered ZenUp products.
    """

    def __init__(self, path):
        self.path = path
        self.products = {}
        self._load()

    def _generateStatusMessage(self, action, from_rev, to_rev):
        """
        Helper to generate a message to be used in the audit log

        @param action: What you are doing (upgrding, downgrading, reverting)
        @param from_rev: Revision you are moving from
        @param to_rev: Revision you are moving
        @return str
        """
        return "{0} from {1} to {2}".format(action, from_rev, to_rev)


    def status_path(self):
        return os.path.join(self.path, "status.yaml")

    def _load(self):
        """
        Loads all of the registered ZenUp products from a status YAML file.

        @raises ZenUpException
        """

        try:
            if not self.path or \
                    not os.path.isdir(self.path):
                raise ZenUpException("Cannot find zenup home: %s" % self.path)
            elif not os.access(self.path, os.R_OK) or \
                    not os.access(self.path, os.W_OK) or \
                    not os.access(self.path, os.X_OK):
                raise ZenUpException("Missing rwx permissions to zenup home: "
                                     "%s" % self.path)

            if os.path.isfile(self.status_path()):
                logger.debug("Loading products from config")
                with open(self.status_path()) as fp:
                    config = yaml.load_all(fp)
                    self.products = ZupProduct.load(config, self)

        except ZenUpException as e:
            logger.error(e)
            raise
        except Exception:
            msg = "Error loading products from %s" % self.status_path()
            logger.exception(msg)
            raise ZenUpException(msg)

    def _save(self, audit_rollover=False):
        """
        Saves metadata about all registered ZenUp products to a status YAML
        file.

        @param audit_rollover: Whether or not the audit log should roll over
        @param products: Tuple of products to update.  If this is passed in, the
        specified products will be updated.  This must be iterable, ex, (product1,)
        """

        try:
            with open(self.status_path(), "w") as fp:
                yaml.dump_all([product.config.__dict__ \
                               for product in self.products.itervalues()],
                              fp, default_flow_style=False, canonical=True)

                try:
                    if audit_rollover:
                        handler = getAuditLogHandler()
                        handler.doRolloverNonEmpty()
                except Exception:
                    msg = "Error rolling over audit log.  Install is complete but audit file will need to be manually renamed."
                    logger.exception(msg)
        except Exception:
            msg = "Error writing to %s.  Changes not saved" % self.status_path()
            logger.exception(msg)
            raise ZenUpException(msg)

    def get_product(self, productKey):
        """
        Lookup a product by either the Product id or name.  Returns a None
        if the product is not found.

        @param productKey:  String describing either the product's name or id
        @returns ZupProduct
        """

        if productKey in self.products:
            return self.products.get(productKey)
        else:
            return next((p for p in self.products.itervalues() \
                         if p.config.name == productKey), None)

    def setup(self, source, home, name=None, install_script=None):
        """
        Initializes a new ZupProduct object and stores the product metadata in
        the status YAML.

        @param source: path to the pristine source
        @param home: path to the product's home
        @param name: (optional) Product's user-specified identifier.
        @param install_script: (optional) Absolute path to install script to use when specifying the source as a path
        @raises ZenUpException
        """

        if source is None or home is None:
            raise ZenUpException("Must supply a source & home parameter")

        # if the source is a directory, tar it up along with the install script
        if os.path.isdir(source):
            def compiledPythonExclude(filename):
                # do not add .pyc or .pyo files
                return ".pyc" in filename or ".pyo" in filename

            def filter(tarinfo):
                # place files in the src/ directory in the tar
                tarinfo.name = "src" + tarinfo.name[tarinfo.name.find("/"):]
                return tarinfo

            config = dict(
                local_diff_directory_blacklist=[],
                local_diff_directory_whitelist=[],
                local_diff_file_pattern_blacklist=[],
                product=name,
                type="product")
            tempDir = tempfile.mkdtemp()
            os.chmod(tempDir, 0755)
            pristineFilename = os.path.join(tempDir, "pristine.tgz")
            with tarfile.open(pristineFilename, "w:gz") as tar:
                tar.add(source, arcname="src")
                for subdir, dirs, files in os.walk(source):
                    for file in files:
                        tar.add(os.path.join(subdir, file), filter=filter, exclude=compiledPythonExclude)
                with open(os.path.join(tempDir, "config.yaml"), "w") as configFile:
                    configFile.write(yaml.dump(config, default_flow_style=False))
                tar.add(os.path.join(tempDir, "config.yaml"), arcname="config.yaml")
                tar.add(install_script, arcname="install")
            os.chmod(pristineFilename, 0755)

            source = pristineFilename
        try:
            if self.get_product(name):
                raise ZenUpException("Product name already in use: %s" % name)

            try:
                PristineSource.load(source)
            except:
                msg = "Error loading source: %s" % os.path.abspath(source)
                logger.exception(msg)
                raise ZenUpException(msg)

            with PristineSource.extract(source) as pristine:
                idval = pristine.config.product
                if self.get_product(idval):
                    raise ZenUpException("Product id already in use: %s" % idval)

                logger.info("Initializing a new product")
                self.products[idval] = ZupProduct.setup(pristine, self.path, home, name)
                product = self.products[idval].config.__dict__
                logger.info("Done adding product %(name)s (%(id_)s)", product)

        except ZenUpException as e:
            logger.error(e)
            raise
        except Exception:
            logger.exception("Error initializing product: %s", os.path.abspath(source))
            raise
        else:
            self._save(audit_rollover=True)

    def remove(self, productKey):
        """
        Unregisters an existing ZenUp product identified my the product's name
        or id.

        @param productKey: String describing the product's name or id
        @raises ZenUpException
        """
        try:
            product = self.get_product(productKey)
            if not product:
                raise ZenUpException("Product not found")

            logger.info("Deleting product %(name)s (%(id_)s)", product.config.__dict__)
            idval = product.config.id_
            del self.products[idval]
            product.remove()
        except ZenUpException as e:
            logger.error(e)
            raise
        except Exception:
            logger.exception("Error deleting product: %s", productKey)
            raise
        finally:
            self._save(audit_rollover=True)

    def info(self, zupfile, respect_config_validity=False):
        """
        Loads information about a zup given a path to the zup

        @param zupfile: Path to the given zup
        @param respect_config_validity: Whether or not to respect the validity
        of the config (per the config_version in the config) when loading
        the zup
        @returns ZupArchive
        """

        try:
            return ZupArchive.load(zupfile,
                                   respect_config_validity=respect_config_validity)
        except ArchiveError, ae:
            logger.exception(ae.message)
            raise ZenUpException(ae.message)
        except Exception:
            msg = "Error while loading zup: %s" % os.path.abspath(zupfile)
            logger.exception(msg)
            raise ZenUpException(msg)

    def diff(self, productKey):
        """
        Performs a local diff against a specified product

        @param productKey: String describing the product's name or id
        @returns LocalDiff
        @raises ZenUpException
        """

        try:
            product = self.get_product(productKey)
            if not product:
                raise ZenUpException("Product not found")

            logger.info("Generating local diff for product %(name)s %(id_)s",
                        product.config.__dict__)
            return product.diff()
        except ZenUpException as e:
            logger.error(e)
            raise
        except KeyboardInterrupt:
            raise ZenUpException(" User cancelled operation")
        except Exception:
            logger.exception("Error generating local diff for %s", productKey)
            raise

    def install(self, zupfile, test=False, force=False):
        """
        Installs a zup for a specified product

        @param zupfile: Path to the zup
        @param test: Doesn't apply patches just checks if the upgrade is doable
        @param force: Roll back local changes and force the zup installation
        @returns ([files added], [files deleted], [files modified], output)
        @raises ZenUpException
        """
        try:
            try:
                zup = self.info(zupfile, respect_config_validity=True)
                product = self.products.get(zup.config.product)
                if not product:
                    raise ZenUpException("Product not found: %s" % zup.config.product)
            except KeyboardInterrupt:
                raise ZenUpException(" User cancelled operation")

            try:
                if product.config.upgrading:
                    if force or test:
                        raise ZenUpException("Upgrade in progress, cannot specify test or force" %
                                             product.config.upgrading)
                    if product.config.upgrading != zup.config.revision:
                        raise ZenUpException("Upgrade to %s already in progress, cannot start upgrade to %s" %
                                             (product.config.upgrading, zup.config.revision))
                if test:
                    result = product.test(zup)
                else:
                    getAuditLogHandler().enable()
                    result = product.install(zup, force)
                    product.config.upgrading = None
                    self._save(audit_rollover=True)
                return result
            except ZenUpException as e:
                logger.error(e)
                raise
            except Exception as e:
                if test:
                    logger.exception("Error testing zup: %s" % zupfile)
                else:
                    logger.exception("Error installing zup: %s" % zupfile)
                raise
        finally:
            getAuditLogHandler().disable()

    def revert(self, productKey, hotfix=False, test=False, force=False):
        """
        Reverts a zup for a specified product

        @param productKey: product Id or name
        @param hotfix: Roll back to the last installed RPS
        @param test: Doesn't apply patches just checks if the downgrade is doable
        @param force: Roll back local changes and force the zup installation
        @returns ([files added], [files deleted], [files modified], output)
        @raises ZenUpException
        """
        try:
            product = self.get_product(productKey)
            if not product:
                raise ZenUpException("Product not found")

            if (hotfix and not product.config.hotfix) or \
                    (not hotfix and not product.config.zupfile):
                raise ZenUpException("Nothing to revert")

            if test:
                result = product.test(no_rps=not hotfix, no_hotfix=hotfix)
            else:
                result = product.install(force=force, no_rps=not hotfix, no_hotfix=hotfix)
                product.config.upgrading = None
                self._save(audit_rollover=True)
            return result

        except ZenUpException as e:
            logger.error(e)
            raise e
        except Exception as e:
            if test:
                logger.exception("Error testing revert")
            else:
                logger.exception("Error reverting zup")

    def restore(self, productKey):
        """
        Restores the files from the current zup onto the environment

        @param productKey: product Id or name
        @returns ([files added], [files deleted], [files modified], output)
        @raises ZenUpException
        """

        try:
            product = self.get_product(productKey)
            if not product:
                raise ZenUpException("Product not found")

            return product.install(force=True)
        except ZenUpException as e:
            logger.error(e)
            raise
        except Exception as e:
            logger.exception("Error restoring zup")