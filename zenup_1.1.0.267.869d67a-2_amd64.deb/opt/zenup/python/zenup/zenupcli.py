##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################

import argparse
import logging
import os
import sys
from datetime import datetime
import string

from zenup import zenupapi, zupproduct, ZenUpException, ZENUPVAR
from zenup.audit import zenupaudit

console = logging.getLogger('console')
UNDOABLE_DOWNGRADE_PROMPT = "WARNING: You will not be able to downgrade after installing this zup.  " \
                            "Press ENTER to continue or <CTRL+C> to quit."

class ZenUpCLI(object):
    """
    ZenUp Client-side tool.
    """

    APP = "zenup"
    DESCRIPTION = "Tool for implementing Zenoss software updates and " \
                  "customer patches."

    def __init__(self, *args):
        self.parser = argparse.ArgumentParser(prog=self.APP,
                                              description=self.DESCRIPTION)
        self._setup()

        if not args:
            args = ['-h']

        try:
            self.api = zenupapi.ZenUp(ZENUPVAR)
            self.args = self.parser.parse_args(args)

            run = getattr(self, "_%s" % self.args.command)
        except Exception:
            console.exception("Error initializing the command-line interface.")

        try:
            console.debug("Running CLI command: %s", ' '.join(args))
            run()
        except ZenUpException as e:
            console.error(e)
            sys.exit(1)
        except Exception:
            console.exception("Error while running command %s", self.args.command)
            sys.exit(1)

    # -- Setup --

    def _setup(self):
        p = self.parser.add_subparsers(dest="command", metavar="<command>")
        self._initcmd(p)
        self._deletecmd(p)
        self._statuscmd(p)
        self._infocmd(p)
        self._diffcmd(p)
        self._installcmd(p)
        self._revertcmd(p)

    def _statuscmd(self, parser):
        """ usage: zenup status [PRODUCT] [--verbose] """
        HELP = "View status on all installed products or a particular " \
               "installed product."

        p = parser.add_parser("status", description=HELP, help=HELP)
        p.add_argument("product", nargs="?",
                       help="Displays information about a product.")
        p.add_argument("--verbose", action="store_true",
                       help="Increases the verbosity of the output")

    def _infocmd(self, parser):
        """ usage: zenup info source [--showfix FIX | --showall] """
        HELP = "View information about a zup"

        p = parser.add_parser("info", description=HELP, help=HELP)
        p.add_argument("source",
                       help="Full path of the zup.")

        group = p.add_mutually_exclusive_group(required=False)
        group.add_argument("--showfix",
                           help="View details of a specific fix.")
        group.add_argument("--showall", action="store_true", default=False,
                           help="View the details of all fixes on the zup "
                                "file.")

    def _initcmd(self, parser):
        """ usage: zenup init source home [--name NAME] """
        HELP = "Initializes a new product for the zenup tool"

        p = parser.add_parser("init", description=HELP, help=HELP)
        p.add_argument("source",
                       help="Product's source code")
        p.add_argument("home",
                       help="Product's home directory")
        p.add_argument("--name", default="",
                       help="Product's display name")
        p.add_argument("--install-script", default=None, dest="install_script",
                       help="Install script to use when specifying a directory as your source to init from")

    def _deletecmd(self, parser):
        """ usage: zenup delete product --force """
        HELP = "Deletes a registered product from the zenup tool"

        p = parser.add_parser("delete", description=HELP, add_help=False)
        p.add_argument("product",
                       help="Product Id")
        group = p.add_mutually_exclusive_group(required=True)
        group.add_argument("--force", action="store_true",
                           help="Required option when deleting a " \
                                "registered product")

    def _diffcmd(self, parser):
        """ usage: zenup diff [PRODUCT] [--summarize] """
        HELP = "Performs a local diff on a registered zenup product"

        p = parser.add_parser("diff", description=HELP, help=HELP)
        p.add_argument("product", nargs="?",
                       help="Product Id")
        p.add_argument("--summarize", dest="verbose", action="store_false",
                       default=True,
                       help="Option to summarize results")

    def _installcmd(self, parser):
        """ usage: zenup install zupfile [--force | --dry-run] """
        HELP = "Applies a zup to a registered zenup product. This action " \
               "cannot be undone."

        p = parser.add_parser("install", description=HELP, help=HELP)
        p.add_argument("zupfile",
                       help="ZUP File")
        group = p.add_mutually_exclusive_group(required=False)
        group.add_argument("--dry-run", action="store_true", dest="dryrun",
                           help="Do not actually change any files; just " \
                                "print what would happen.")
        group.add_argument("--force", action="store_true",
                           help="Apply zup while reverting ALL local changes")

    def _revertcmd(self, parser):
        """ usage: zenup revert [product] [--rps | --hotfix] [--force | --dry-run]
                   zenup revert [product] --force"""
        HELP = "Uninstalls a zup or hotfix, permitted the archive does not " \
               "implement any database changes.  If no zup/hotfix is " \
               "specified and --force is used, local changes will be " \
               "reverted instead."

        usage =  "zenup revert [product] [--rps | --hotfix] [--force | --dry-run] \n" \
                 "       zenup revert [product] --force"
        p = parser.add_parser("revert", description=HELP, help=HELP, usage=usage)
        p.add_argument("product", nargs="?", help="Product Id")

        group = p.add_mutually_exclusive_group(required=False)
        group.add_argument("--rps", action="store_true",
                           help="Revert the file system to pristine if allowed "
                                "by the currently installed zup")
        group.add_argument("--hotfix", action="store_true",
                           help="Revert the installed hotfix and revert the " 
                                "file system to the latest installed zup.")

        group = p.add_mutually_exclusive_group(required=False)
        group.add_argument("--dry-run", action="store_true", dest="dryrun",
                           help="Do not actually change any files; just " \
                                "print what would happen.")
        group.add_argument("--force", action="store_true",
                           help="Apply zup while reverting ALL local changes")

    # -- Execution --

    def _status(self):
        if self.args.product:
            product = self.api.get_product(self.args.product)
            if product is not None:
                products = [product]                
            else:
                raise ZenUpException("Product not found")

        elif self.api.products:
            products = self.api.products.values()
        else:
            products = []
            console.info("No Products Installed")
            return

        console.info("")
        for idx,p in enumerate(products):
            pconf = p.config.__dict__
            console.info("Product: %(name)s (id = %(id_)s)", pconf)
            console.info("Home: %(home)s", pconf)
            console.info("Revision: %(revision)d", pconf)
            console.info("Upgrading: %(upgrading)r", pconf)
            upgrading = False
            if pconf["upgrading"]:
                upgrading = True
                last_attempted_step = zenupaudit.ZenUpAudit().getLastAttempted()
                console.info("Last Attempted Step: %s", last_attempted_step)

            if p.config.zupfile:
                console.info("Minimum: %(minimum)d",
                             self.api.info(p.config.zupfile).config.__dict__)

            if p.config.hotfix:
                console.info("Hotfix: %(hotfix)s", pconf)

            lastupdate = \
                datetime.fromtimestamp(pconf['lastupdate']).strftime("%c")
            console.info("Updated On: %s", lastupdate)

            if self.args.verbose:
                console.info("")
                console.info("Fixes:")
                if p.config.zupfile:
                    archive = self.api.info(p.config.zupfile)
                    for fix in archive.manifest.fixes:
                        mfix = fix.__dict__
                        console.info("[%(id)s] %(description)s", mfix)
                else:
                    console.info("No RPS installed")

                if p.config.hotfix:
                    console.info("==== Hotfixes ====")
                    archive = self.api.info(p.config.hotfix)
                    for fix in archive.manifest.fixes:
                        mfix = fix.__dict__
                        console.info("[%(id)s] %(description)s", mfix)

            if len(products) != (idx + 1):
                console.info("---")

    def _info(self):
        archive = self.api.info(self.args.source)

        if self.args.showfix:
            idval = self.args.showfix
            mfixes = archive.manifest.fixes
            fixes = [f for f in mfixes if f.id.upper() == idval.upper()]

            if len(fixes) == 0:
                raise ZenUpException("Not found")
        elif self.args.showall:
            fixes = archive.manifest.fixes            
        else:
            config = archive.config.__dict__
            created = config['created'].strftime("%c")
            console.info("File: %s", self.args.source)
            console.info("Product: %(product)s", config)
            console.info("Revision: %(revision)d", config)
            console.info("Minimum: %(minimum)d", config)
            console.info("Created: %s", created)
            console.info("")
            console.info("Fixes:")
            for fix in archive.manifest.fixes:
                mfix = fix.__dict__
                console.info("  [%(id)s] %(description)s", mfix)

            console.info("")
            self._get_printable_phases(archive.config)
            return

        try:
            archive.extract()            
            for i in xrange(len(fixes)):
                fix = fixes[i]
                
                if i > 0:
                    console.info("*" * 79)
                    console.info("*" * 79)
                    
                console.info("[%(id)s] %(description)s", fix.__dict__)
                console.info("")

                if len(fix.patches) == 0:
                    console.info("Binary changes only")
                    continue
                
                for j in xrange(len(fix.patches)):
                    patch = fix.patches[j]
                    console.info("patch file: %s" % patch)
                    with open(os.path.join(archive.patches_path(), patch)) as fp:
                        for line in fp.readlines():
                            console.info(line.rstrip())

                    if j < len(fix.patches) - 1:
                        console.info("")
                        console.info("")
                        console.info("=" * 79)
                console.info("")
            console.info("")
        finally:
            archive.remove()

    def _init(self):
        installScript = None

        if os.path.isdir(self.args.source):
            if not self.args.install_script or not self.args.name:
                raise ZenUpException("Please specify an install script and product name when using init with an existing directory")
            if not os.path.exists(self.args.install_script):
                raise ZenUpException("Specified install script does not exist")
            if not os.path.isfile(self.args.install_script):
                raise ZenUpException("Specified install script must be a file")
            installScript = os.path.abspath(self.args.install_script)
        elif self.args.install_script:
            raise ZenUpException("Source must be a directory if specifying an install script")

        self.api.setup(self.args.source, self.args.home, self.args.name, installScript)


        console.info("Success!")

    def _delete(self):
        self.api.remove(self.args.product)
        console.info("Success!")

    def _diff(self):

        if self.args.product is not None:
            product = self.args.product
        elif len(self.api.products) == 1:
            product = self.api.products.iterkeys().next()
        else:
            console.info("Product must be specified")
            return
        
        diff = self.api.diff(product)
        diff.verbose = self.args.verbose
        
        for line in str(diff).split("\n"):
            console.info(line.rstrip())

    def _revert(self):
        # Get the product
        numProducts = len(self.api.products)
        if self.args.product is not None:
            product = self.args.product
        elif numProducts == 1:
            product = self.api.products.iterkeys().next()
        else:
            if numProducts == 0:
                console.info("No products available")
            elif numProducts > 1:
                console.info("Product must be specified")
            return

        if not self.args.dryrun:
            if self.args.force:
                try:
                    raw_input("WARNING: ALL custom patches and edits will be "
                              "reverted!  Press ENTER to continue or <CTRL+C> "
                              "to quit.")
                except KeyboardInterrupt:
                    console.error("")
                    console.error("User cancelled operation")
        try:
            if self.args.rps or self.args.hotfix:
                added, deleted, modified, output = \
                    self.api.revert(product,
                                    hotfix=self.args.hotfix, 
                                    test=self.args.dryrun, 
                                    force=self.args.force)
            elif self.args.force:
                self.api.restore(product)
            else:
                console.error("Insufficient arguments")
                console.error("To revert custom patches, use `zenup revert --force`")
                raise ZenUpException()
            
            if self.args.rps or self.args.hotfix:
                if self.args.dryrun:
                    console.info("")
                    console.info("Files modified:")
                    for f in modified: console.info(f)
                    console.info("")
                    console.info("Files added:")
                    for f in added: console.info(f)
                    console.info("")
                    console.info("Files deleted:")
                    for f in deleted: console.info(f)
                    if output:
                        console.info("")
                        console.info("Results:")
                        for line in output.split("\n"): console.info(line)
                else:
                    console.debug("")
                    console.debug("Files modified:")
                    for f in modified: console.debug(f)
                    console.debug("")
                    console.debug("Files added:")
                    for f in added: console.debug(f)
                    console.debug("")
                    console.debug("Files deleted:")
                    for f in deleted: console.debug(f)
                    if output:
                        console.debug("")
                        console.debug("Results:")
                        for line in output.split("\n"): console.debug(line)
            else:
                console.info("Success!")

        finally:
            if self.args.dryrun:
                console.info("No changes have been applied to your system")

    def _install(self):
        if not self.args.dryrun:
            if self.args.force:
                try:
                    raw_input("WARNING: ALL custom patches and edits will be "
                              "reverted!  Press ENTER to continue or <CTRL+C> "
                              "to quit.")
                except KeyboardInterrupt:
                    console.error("")
                    console.error("User cancelled operation")
                    return

        # Make sure it's OK to install a new zup if we can't downgrade from it
        new_zup_config = self.api.info(self.args.zupfile).config
        new_zup_minimum = new_zup_config.minimum
        new_zup_revision = new_zup_config.revision
        if new_zup_config.type != 'hotfix' and new_zup_minimum == new_zup_revision:
            if ('INTERACT' in os.environ and os.environ['INTERACT'] != '0') or 'INTERACT' not in os.environ:
                raw_input(UNDOABLE_DOWNGRADE_PROMPT)

        product = self.api.products.get(new_zup_config.product)
        last_attempted_step = None
        if product and product.config.upgrading:
            last_attempted_step = zenupaudit.ZenUpAudit().getLastAttempted()
        console.info("")
        self._get_printable_phases(new_zup_config, last_attempted_step)
        console.info("")

        if last_attempted_step and product.config.upgrading:
            raw_input("In-progress update detected - will replay pre-install & staging steps, then pick up at "
                      "the last previously attempted step ({0}).  Press ENTER to continue or <CTRL+C> to quit".format(last_attempted_step))

        try:
            added, deleted, modified, output = \
                   self.api.install(self.args.zupfile,
                                    test=self.args.dryrun,
                                    force=self.args.force)
            
            if self.args.dryrun:
                console.info("")
                console.info("Files modified:")
                for f in modified: console.info(f)
                console.info("")
                console.info("Files added:")
                for f in added: console.info(f)
                console.info("")
                console.info("Files deleted:")
                for f in deleted: console.info(f)
                if output:
                    console.info("")
                    console.info("Results:")
                    for line in output.split("\n"): console.info(line)
            else:
                console.debug("")
                console.debug("Files modified:")
                for f in modified: console.debug(f)
                console.debug("")
                console.debug("Files added:")
                for f in added: console.debug(f)
                console.debug("")
                console.debug("Files deleted:")
                for f in deleted: console.debug(f)
                if output:
                    console.debug("")
                    console.debug("Results:")
                    for line in output.split("\n"): console.debug(line)
                console.info("Success!")
        finally:
            if self.args.dryrun:
                console.info("No changes have been applied to your system")       

    def _get_printable_phases(self, config, last_attempted=None):
        """
        Print a pretty list of the steps in the zup to the console log.
        If last_completed is passed, print with an indication of what's been done
        and what hasn't
        @param config: zup config object
        @param last_attempted: string representation of the last ZupLifecycleStep attempted
        @return: void
        """
        console.info("Install Steps:")
        ctr = 0
        status = 'c'
        for phase, phase_desc in zupproduct.ZupProduct.phase_map.iteritems():
            ctr += 1
            console.info("  %s) %s:", ctr, phase_desc)
            alpha = string.ascii_uppercase
            if phase == "patch":
                steps = [("Lay down changes", "File Patching")]
            else:
                steps = [("---" if step.description in (None, "") else step.description, step.__str__().strip())
                         for step in config[phase].steps]

            if last_attempted:
                for idx,step in enumerate(steps):
                    if step[1] == last_attempted:
                        status = 'i'
                    console.info("      [%s] %s) %s (%s)", status, alpha[idx], step[0], step[1])
                    if status == 'i':
                        status = ' '
            else:
                for idx,step in enumerate(steps):
                    console.info("      %s) %s (%s)", alpha[idx], step[0], step[1])

        if last_attempted:
            console.info("(c = complete, i = incomplete)")
            console.info("NOTE: Pre-install & staging steps (1 + 2) are executed on every install attempt")

if __name__ == '__main__':
    ZenUpCLI(*sys.argv[1:])
