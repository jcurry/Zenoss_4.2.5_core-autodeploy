##############################################################################
# 
# Copyright (C) Zenoss, Inc. 2013, all rights reserved.
# 
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
# 
##############################################################################

import logging
import os
import shutil
import tempfile
import time
from itertools import chain, count
from collections import OrderedDict

from zenup import ZenUpException
from zenup.config.product import ProductConfiguration
from zenup.archive.source import PristineSource
from zenup.archive.zup import ZupArchive
from zenup.archive import ArchiveError
from zenup import utils
from zenup import localdiff
from zenup.audit.zenupaudit import ZenUpAudit

ZUP_WORKING_DIR = 'ZUP_WORKING_DIR'
ZUP_PRODUCT_DIR = 'ZUP_PRODUCT_DIR'
ZUP_SOURCE_DIR = 'ZUP_SOURCE_DIR'

console = logging.getLogger('console')
auditLogger = logging.getLogger("audit")

class ZupProductError(ZenUpException):
    pass

class ZupProduct(object):

    phase_map = OrderedDict([("check", "Non-Destructive Pre-Install Steps"),
                             ("pre", "Staging Steps"),
                             ("patch", "File Patching"),
                             ("post", "Post-Install Steps")])

    """
    Loads and registers ZenUp products.  It loads information about a product,
    initializes and uninitializes products, computes the local diff against
    existing products, and performs upgrades/downgrades with compatible zups.
    """
    def __init__(self, **config):
        self.config = ProductConfiguration(config)
        # In case we encounter a status.yaml with an unqualified zupfile param
        if self.config.zupfile and not self.config.zupfile.startswith(self.packs_path()):
            config['zupfile'] = os.path.join(self.packs_path(), self.config.zupfile)
            self.config = ProductConfiguration(config)
        self.pristine = None
        self.rps = None
        self.hotfix = None

    @classmethod
    def load(cls, products, api):
        """
        Loads all ZenUp products from a file-like object.
        
        @param products: list of all products
        @param api: instance of zenup api, cannot be None
        @returns {str productId: ZupProduct product}
        """
        
        console.debug('Initializing Products')
        result = {}
        for p in products:
            obj = cls(**p)
            obj.api = api
            result[obj.config.id_] = obj
        return result

    def source_path(self):
        return os.path.join(self.config.path, "source.tgz")

    def packs_path(self):
        return os.path.join(self.config.path, "packs")

    @classmethod
    def setup(cls, source, path, home, name=None):
        """
        Registers a ZenUp Product and initializes metadata about a product.
        
        @param source: PristineSource object loaded from a tgz
        @param path: parent path where the product's metadata will be stored.
        @param home: product's home directory (i.e. $ZENHOME)
        @param name: (optional) Product's pretty identifier
        @returns ZupProduct
        """
        
        idval = source.config.product
        p = os.path.join(path, idval)

        # Validate path and home vars
        console.info("Initializing new product: %s", idval)
        if not os.path.isdir(path) or \
           not os.access(path, os.R_OK) or \
           not os.access(path, os.W_OK) or \
           not os.access(path, os.X_OK):
            raise ZupProductError("Cannot setup product at path %s" % path)
        elif os.path.exists(p):
            raise ZupProductError("Product path already exists: %s" % p)
        elif not os.path.isdir(home):
            raise ZupProductError("Cannot find product home: %s" % home)
        console.debug("Creating product path: %s", p)

        # Initialize product
        obj = None
        try:
            os.mkdir(p)
            obj = cls(id_=idval, name=name or idval, home=home, path=p)
            os.environ[ZUP_SOURCE_DIR] = source.path
            os.environ[ZUP_PRODUCT_DIR] = home
            console.info("Running installation script")            
            source.run_script("install")
            console.info("Copying pristine source")            
            source.compress(obj.config.path, 
                            filename=os.path.basename(obj.source_path()))
            obj.config.created = time.time()
            obj.config.lastupdate = obj.config.created
        except Exception:
            console.info("Initialization failed, cleaning up")
            if os.path.exists(p):
                shutil.rmtree(p)
            raise
        finally:
            if ZUP_SOURCE_DIR in os.environ:
                del os.environ[ZUP_SOURCE_DIR]
            if ZUP_PRODUCT_DIR in os.environ:
                del os.environ[ZUP_PRODUCT_DIR]
                
        return obj

    def remove(self):
        console.debug("Removing product directory: %s" % self.config.path)
        shutil.rmtree(self.config.path)
                
    def diff(self):
        """
        Performs a local diff against the installed product

        @returns LocalDiff
        """
        
        # Open the pristine
        console.info("Loading pristine source for product %s" % self.config.id_)
        with PristineSource.extract(self.source_path()) as pristine:
            config = pristine.config
            if self.config.zupfile:
                # Open the rps zup and load the patches        
                console.info("Loading installed RPS: %s" % self.config.zupfile)
                with ZupArchive.extract(self.config.zupfile) as zup:
                    config = zup.config
                    for p in zup.apply_patches(pristine.source_path()): pass
            if self.config.hotfix:
                # Open the hotfix zup and load the patches
                console.info("Loading installed Hotfix: %s" % self.config.hotfix)
                with ZupArchive.extract(self.config.hotfix) as zup:
                    config = zup.config
                    for p in zup.apply_patches(pristine.source_path()): pass

            # Get the diff
            console.info("Calculating local diff")
            diff = localdiff.LocalDiff(pristine.source_path(), self.config.home)
            diff.run(config)
            return diff

    def _test(self, new=None, force=False, no_rps=False, no_hotfix=False):
        # Get the current and new revisions and verify install
        pristine = self.pristine
        rps = self.rps
        hotfix = self.hotfix
        revertCustomChanges = False
        current_rps = rps.config.revision if rps else 0

        if (new and new.is_rps()) or no_rps:
            is_rps = True
            current = rps
        elif (new and new.is_hotfix()) or no_hotfix:
            is_rps = False
            current = hotfix
            new_rps = new.config.rps if new else current_rps

            if new_rps != current_rps:
                raise ZupProductError("Hotfix is not compatible with the "
                                      "current RPS.  (RPS != %s)" % new_rps)
            if new and current:
                new_customer = new.config.customer
                current_customer = current.config.customer

                if new_customer != current_customer:
                    raise ZupProductError("Incompatible hotfix")
        elif not new and force:
            revertCustomChanges = True
            is_rps = not hotfix
            current = hotfix or rps
        else:
            raise ZupProductError("Bad parameters")

        if current:
            current_config = current.config
            current_product = current.config.product
            current_revision = current.config.revision
            current_minimum = current.config.minimum
        else:
            current_config = pristine.config
            current_product = pristine.config.product
            current_revision = 0
            current_minimum = 0

        if new:
            new_revision = new.config.revision
        elif revertCustomChanges:
            new_revision = current_revision
        else:
            new_revision = 0

        if not revertCustomChanges and current_revision == new_revision:
            raise ZupProductError("Already at the current revision")
        elif current_minimum > new_revision:
            raise ZupProductError("Cannot downgrade to this zup (revision <= %s)"
                                  % current_minimum)
        elif new and current_product != new.config.product:
            raise ZupProductError("Incompatible product")

        config = new.config if new else current_config
        downgrade = current_revision > new_revision
        sandbox = os.path.dirname(pristine.path)
        affected_files = set()
        output = None
        diff = localdiff.LocalDiff(pristine.source_path(), self.config.home)

        files_added = []
        files_deleted = []
        files_modified = []

        if revertCustomChanges:
            console.info("Checking environment")

            # Load the rps onto the pristine, if exists
            if rps:
                console.debug("Applying the current rps onto the pristine")
                rps.extract(sandbox)
                for patch in rps.apply_patches(pristine.source_path()): pass

            # Load the hotfix onto the pristine, if exists
            if hotfix:
                console.debug("Applying the current hotfix onto the pristine")
                hotfix.extract(sandbox)
                for patch in hotfix.apply_patches(pristine.source_path()): pass

            console.info("Calculating local diff")
            diff.run(config)
        elif downgrade:
            console.info("Computing downgrade requirements")

            # If installing a hotfix, load the RPS onto the pristine (if one
            # exists)
            if not is_rps and rps:
                console.debug("Applying the current rps onto the pristine")
                rps.extract(sandbox)
                for patch in rps.apply_patches(pristine.source_path()): pass

            # The current zup will have all the patches, so we only need
            # to extract that zup
            current.extract(sandbox)

            # Set environment variables for running scripts
            os.environ[ZUP_PRODUCT_DIR] = self.config.home
            os.environ[ZUP_SOURCE_DIR] = pristine.path
            os.environ[ZUP_WORKING_DIR] = current.path

            patch_count = len(new.manifest.patches) if new else 0

            # Lay down all of the patches in the zup to calculate the local
            # diff
            i = count()
            for patch in current.apply_patches(pristine.source_path()):
                if i.next() >= patch_count:
                    # Figure out what files we will have to roll back
                    changes = current.manifest.changes[patch]
                    affected_files.update(changes.adds)
                    affected_files.update(changes.deletes)
                    affected_files.update(changes.modifies)

            # If installing an rps, load the hotfix onto the pristine (if one
            # exists)
            if is_rps and hotfix:
                console.debug("Applying the current hotfix onto the pristine")
                hotfix.extract(sandbox)
                for patch in hotfix.apply_patches(pristine.source_path()):
                    # Set files affected by the hotfix
                    changes = hotfix.manifest.changes[patch]
                    affected_files.update(changes.adds)
                    affected_files.update(changes.deletes)
                    affected_files.update(changes.modifies)

            console.info("Calculating local diff")
            # Narrow down the number of files to check if a downgrade is
            # forced, otherwise all files will have to be checked for rollback
            if not force:
                config.dirWhitelist = []
                config.fileWhitelist = affected_files
            diff.run(config)

            # Now we need pristine to be at the new patch level, so delete
            # the pristine directory and only roll on the patches described by
            # the new zup (unless reverting to pristine, then no patches will
            # be rolled on)
            console.debug("Setting the new patch level on the pristine")
            pristine.remove()
            pristine.extract(sandbox)

            if not is_rps and rps:
                # Install the current RPS
                for patch in rps.apply_patches(pristine.source_path()): pass

            pgen = current.apply_patches(pristine.source_path())
            for i in range(patch_count): pgen.next()
            pgen.close()
        else:
            console.info("Computing upgrade requirements")

            # The new zup will have all of the patches, so we only need to
            # extract that zup
            new.extract(sandbox)

            # Set environment variables for running scripts
            os.environ[ZUP_PRODUCT_DIR] = self.config.home
            os.environ[ZUP_SOURCE_DIR] = pristine.path
            os.environ[ZUP_WORKING_DIR] = new.path

            # Some staging steps need to know if patching has happened yet or not (resuming an install)
            if self.config.upgrading and "post" in ZenUpAudit().getLastAttempted():
                patching_happened = "1"
            else:
                patching_happened = "0"
            os.environ["POST_PATCHING"] = patching_happened

            # If installing a hotfix, load the rps onto the pristine (if one
            # exists)
            if not is_rps and rps:
                console.debug("Applying the current RPS onto the pristine")
                rps.extract(sandbox)
                for patch in rps.apply_patches(pristine.source_path()): pass

            patch_count = len(current.manifest.patches) if current else 0

            # Only roll on the patches that are currently installed to compute
            # the local diff
            pgen = new.apply_patches(pristine.source_path())
            for i in range(patch_count): pgen.next()

            # Roll on hotfix patches (if exists)
            if is_rps and hotfix:
                console.debug("Applying the current hotfix onto the pristine")
                hotfix.extract(sandbox)
                for patch in hotfix.apply_patches(pristine.source_path()):
                    # Set affected files by the hotfix
                    changes = hotfix.manifest.changes[patch]
                    affected_files.update(changes.adds)
                    affected_files.update(changes.deletes)
                    affected_files.update(changes.modifies)

            # Run the check script once the pristine environment has been
            # established.
            if new:
                self._run_scripts(new, "check")

            # Figure out what files will be changed by the new zup
            for patch in new.manifest.patches[patch_count:]:
                changes = new.manifest.changes[patch]
                affected_files.update(changes.adds)
                affected_files.update(changes.deletes)
                affected_files.update(changes.modifies)

            # Narrow down the number of files to be checked for local diff if
            # not forcing an installation, otherwise all files will have to be
            # checked for upgrade.
            console.info("Calculating local diff")
            if not force:
                config.dirWhitelist = []
                config.fileWhitelist = affected_files
            diff.run(config)

            console.debug("Setting the new patch level on the pristine")
            if is_rps and hotfix:
                # Our pristine environment is dirty because of the hotfix, so
                # reload pristine and only apply patches from the new rps
                pristine.remove()
                pristine.extract(sandbox)
                pgen.close()
                pgen = new.apply_patches(pristine.source_path())

            # Set pristine to the new patch level
            for patch in pgen: pass

        if diff.unknown:
            # Unknown files are files with restricted access
            for f in diff.unknown: console.error("Cannot merge path %s", f)
            raise ZupProductError("Unable to install zup")
        elif force:
            # Force means roll back any local changes found
            affected_files.update(diff.added)
            affected_files.update(diff.deleted)
            affected_files.update(diff.modified)
        else:
            # Restore any files that were deleted to the file affected by the
            # zup
            while diff.deleted: del diff.changeset[diff.deleted.pop()]
            if diff.changeset:
                auditer = ZenUpAudit()
                if not auditer.stepCompleted("File Patching"):
                    # Try to merge local diffs
                    console.info("File patching not completed yet, merging local diffs")
                    auditLogger.info("Merging local diffs")
                    output = self._merge(pristine, diff)
                else:
                    auditLogger.info("Skipping merging local diffs")
                    console.info("Skipping merging local diffs")

        console.info("Comparing affected files")

        # Determine which files have been added, deleted or changed by
        # comparing the existence of those two files in the pristine sandbox vs
        # what is installed on the system
        for filename in affected_files:
            in_pristine = os.path.exists(os.path.join(pristine.source_path(), filename))
            in_installed = os.path.exists(os.path.join(self.config.home, filename))
            is_dir = os.path.isdir(os.path.join(pristine.source_path(), filename))

            is_added = in_pristine and not in_installed
            is_deleted = not in_pristine and in_installed
            is_modified = in_pristine and in_installed and not is_dir

            if is_added:
                files_added.append(filename)
            elif is_deleted:
                files_deleted.append(filename)
            elif is_modified:
                files_modified.append(filename)

        return files_added, files_deleted, files_modified, output

    def _merge(self, pristine, diff):
        sandbox = os.path.dirname(pristine.path)
        diff_file = os.path.join(sandbox,"merge.diff")
        reject_file = os.path.join(sandbox, "merge.rej")

        pwd = os.getcwd()
        fp = None
        try:
            os.chdir(pristine.source_path())
            fp = utils.fileopen(diff_file, "w+")
            fp.write(str(diff))
            fp.seek(0)

            output, stdout, stderr = \
                utils.patch(fp, "-N", "-r%s" % reject_file, "-p0")
            ret = stdout.replace(reject_file, "DEBUG")

            if output == utils.PATCH_WARN:    
                console.info("Checking patch conflicts")
                    
                FORWARD_PATCH_MESSAGE = \
                    "Reversed (or previously applied) patch detected!  " \
                    "Skipping patch."
                NEW_FILE_MESSAGE = "patching file"

                if os.path.isfile(reject_file):
                    rfp = None
                    try:
                        rfp = utils.fileopen(reject_file, "r")
                        console.debug("Merge Conflicts:")
                        for line in rfp.readlines(): 
                            console.debug(line.rstrip('\n'))
                    finally:
                        if rfp is not None:
                            try:
                                rfp.close()
                            except Exception: pass

                ignore = False
                for line in stdout.splitlines():
                    if line.startswith(NEW_FILE_MESSAGE):
                        ignore = False
                    elif line == FORWARD_PATCH_MESSAGE:
                        ignore = True
                    elif line.rfind(reject_file) > 0:
                        if not ignore:
                            raise ZupProductError(ret)
            elif output == utils.PATCH_ERROR:
                raise ZupProductError(stderr)

            return ret
        finally:
            if fp is not None:
                try:
                    fp.close()
                except Exception: pass

            os.chdir(pwd)

    def test(self, zup=None, no_rps=False, no_hotfix=False):
        """
        Tests a zup installation.  Creates a sandbox environment with the
        pristine source, applies zup patches, merges any local diffs and
        returns a tuple with all of the affected files as well as the output
        from the merged local diff.

        @param zup: ZupArchive object to be tested for install
        @returns ([added files], [deleted files], [modified files], str output)
        """
        
        sandbox = None
        try:
            sandbox = tempfile.mkdtemp()
            console.debug("Initializing sandbox: %s", sandbox)
            self.pristine = PristineSource(self.source_path())
            self.pristine.extract(sandbox)

            self.rps = ZupArchive.load(self.config.zupfile,
                                       respect_config_validity=False) \
                if self.config.zupfile else None

            self.hotfix = ZupArchive.load(self.config.hotfix,
                                          respect_config_validity=False) \
                if self.config.hotfix else None
            
            result = self._test(new=zup, no_rps=no_rps, no_hotfix=no_hotfix)

            return result
        except KeyboardInterrupt:
            return
        finally:
            console.debug("Destroying sandbox")            
            if ZUP_PRODUCT_DIR in os.environ:
                del os.environ[ZUP_PRODUCT_DIR]
            if ZUP_SOURCE_DIR in os.environ:
                del os.environ[ZUP_SOURCE_DIR]
            if ZUP_WORKING_DIR in os.environ:
                del os.environ[ZUP_WORKING_DIR]
            if os.path.isdir(sandbox):
                shutil.rmtree(sandbox)

    def install(self, zup=None, force=False, no_rps=False, no_hotfix=False):
        """
        Attempts to install a zup onto a product's environment.  Creates a
        sandbox environment with pristine source, applies the zup patches,
        merges any local diffs, and returns a tuple with all of the affected
        files as well as output from the merged local diff

        @param zup: (optional) ZupArchive object to be installed
        @param force: (optional) boolean that rolls back all local changes
        @param no_rps: (optional) boolean that reverts the source to pristine
        @param no_hotfix: (optional) boolean that reverts hotfix changes
        @returns ([added files], [deleted files], [modified files], str output)
        """
        auditer = ZenUpAudit()
        message = "Install from {0} to {1}".format(self.config.revision, zup.config.revision) if zup else "NO ZUP"
        auditLogger.begin(message)
        sandbox = None
        try:
            try:
                sandbox = tempfile.mkdtemp()
                console.debug("Initializing sandbox: %s", sandbox)
                self.pristine = PristineSource(self.source_path())
                self.pristine.extract(sandbox)

                self.rps = ZupArchive.load(self.config.zupfile,
                                           respect_config_validity=False) \
                    if self.config.zupfile else None

                self.hotfix = ZupArchive.load(self.config.hotfix,
                                              respect_config_validity=False) \
                    if self.config.hotfix else None

                files_added, files_deleted, files_modified, output = \
                        self._test(new=zup, force=force, no_rps=no_rps,
                                   no_hotfix=no_hotfix)

                upgrade = zup is not None and zup.is_open()

                if upgrade:
                    console.info("Running pre-copy steps")
                    self._run_scripts(zup, "pre")
                    
            except KeyboardInterrupt:
                raise ZupProductError(" User cancelled operation")

            console.info("Copying files")
            copy_files = sorted(chain(files_added, files_modified))
            self.config.upgrading = zup.config.revision if zup else None
            self.api._save()
            if not auditer.stepCompleted("File Patching"):
                auditLogger.begin("File Patching")
                for filename in copy_files:
                    console.debug("Copying %s" % filename)
                    src = os.path.join(self.pristine.source_path(), filename)
                    dest = os.path.join(self.config.home, filename)

                    if os.path.isdir(src):
                        os.makedirs(dest)
                    else:
                        destdir = os.path.dirname(dest)
                        if not os.path.exists(destdir):
                            os.makedirs(destdir)
                        shutil.copyfile(src, dest)

                delete_files = sorted(files_deleted, reverse=True)
                for filename in delete_files:
                    console.debug("Deleting %s" % filename)
                    dest = os.path.join(self.config.home, filename)
                    shutil.rmtree(dest) if os.path.isdir(dest) else os.remove(dest)
                auditLogger.end("File Patching")
            else:
                auditLogger.info("Skipping File Patching")
                console.info("Skipping File Patching")
            if upgrade:
                console.info("Running post-copy steps")
                self._run_scripts(zup, "post", auditer)

            console.info("Updating product information")

            if zup:
                if zup.is_rps():
                    zupfile = "%s-SP%s.zup" % (self.config.id_, zup.config.revision)
                    path = os.path.join(self.packs_path(), zupfile)
                    self.config.zupfile = path
                    self.config.revision = zup.config.revision
                    self.config.hotfix = ""
                elif zup.is_hotfix():
                    hotfix = "%s-SP%s-X%s.zup" % (self.config.id_, zup.config.rps, zup.config.revision)
                    path = os.path.join(self.packs_path(), hotfix)
                    self.config.hotfix = path
                else:
                    # This should never happen
                    raise ZupProductError("Unsupported ZUP: %s" % zup.config.type)

                if not os.path.exists(self.packs_path()):
                    os.mkdir(self.packs_path())
                shutil.copyfile(zup.resource, path)
            else:
                if no_rps:
                    self.config.zupfile = ""
                    self.config.revision = 0
                    self.config.hotfix = ""
                elif no_hotfix:
                    self.config.hotfix = ""
                elif force:
                    pass
                else:
                    # This should never happen
                    raise ZupProductError("Bad parameters")

            self.config.lastupdate = time.time()
            auditLogger.end(message)
        finally:
            console.debug("Destroying sandbox")
            if ZUP_PRODUCT_DIR in os.environ:
                del os.environ[ZUP_PRODUCT_DIR]
            if ZUP_SOURCE_DIR in os.environ:
                del os.environ[ZUP_SOURCE_DIR]
            if ZUP_WORKING_DIR in os.environ:
                del os.environ[ZUP_WORKING_DIR]
            if os.path.isdir(sandbox):
                shutil.rmtree(sandbox)

        return files_added, files_deleted, files_modified, output

    def _run_scripts(self, zup, lifecyclePhase, auditer=None):
        for script in zup.config[lifecyclePhase].steps:
            localScript = script.__str__()
            if auditer and auditer.stepCompleted(localScript):
                auditLogger.info("Skipping script %s" % localScript)
                console.info("Skipping script %s" % localScript)
            else:
                auditLogger.begin(localScript)
                try:
                    zup.run_script(localScript)
                except ArchiveError as e:
                    auditLogger.error(e)
                    raise e
                auditLogger.end(localScript)
